import SwiftUI
import PhotosUI
import PencilKit
import UIKit

@MainActor
final class PageTextLayout {
    private let storage: NSTextStorage
    let manager: NSLayoutManager
    private let container: NSTextContainer
    let visibleGlyphs: NSRange
    let finalBlankLineFits: Bool

    init(text: NSAttributedString, size: CGSize, objects: [PageObject]) {
        let storage = NSTextStorage(attributedString: text)
        let manager = NSLayoutManager()
        let container = NSTextContainer(size: CGSize(width: size.width, height: 10_000_000))
        container.lineFragmentPadding = 0
        container.lineBreakMode = .byWordWrapping
        container.exclusionPaths = PageDocument.paths(objects, in: size)
        storage.addLayoutManager(manager)
        manager.addTextContainer(container)
        // Query the container, including control glyphs and blank paragraphs.
        manager.ensureLayout(for: container)
        let candidates = manager.glyphRange(for: container)
        var end = 0
        if candidates.length > 0 {
            manager.enumerateLineFragments(forGlyphRange: candidates) { rect, used, _, glyphs, stop in
                guard max(rect.maxY, used.maxY) <= size.height + 0.5 else {
                    stop.pointee = true
                    return
                }
                end = NSMaxRange(glyphs)
            }
        }
        self.storage = storage
        self.manager = manager
        self.container = container
        visibleGlyphs = NSRange(location: 0, length: end)
        finalBlankLineFits = manager.extraLineFragmentTextContainer !== container
            || manager.extraLineFragmentRect.maxY <= size.height + 0.5
    }

    var visibleCharacters: Int {
        guard visibleGlyphs.length > 0 else { return 0 }
        return NSMaxRange(manager.characterRange(forGlyphRange: visibleGlyphs, actualGlyphRange: nil))
    }
}

@MainActor
final class PageDocument: ObservableObject {
    static func typeface(_ size: CGFloat, weight: UIFont.Weight = .regular) -> UIFont {
        let base = UIFont.systemFont(ofSize: size, weight: weight)
        return UIFont(name: weight == .regular ? "Georgia" : "Georgia-Bold", size: size) ?? base
    }
    static let font = typeface(20)
    static let attributes: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: UIColor.label]
    weak var view: UITextView?
    private let editors = NSMapTable<NSUUID, UITextView>.strongToWeakObjects()
    var onEdit: (UUID, UITextView) -> Void = { _, _ in }
    var activePage: UUID?

    func register(_ editor: UITextView, for page: UUID) {
        editors.setObject(editor, forKey: page as NSUUID)
    }

    func activate(_ page: UUID) {
        if let editor = editors.object(forKey: page as NSUUID) {
            activePage = page
            view = editor
        }
    }

    private func notifyEdit(_ editor: UITextView) {
        guard let activePage else { return }
        DispatchQueue.main.async { [weak self, weak editor] in
            guard let editor else { return }
            self?.onEdit(activePage, editor)
        }
    }

    static func overflow(_ text: NSAttributedString, in size: CGSize, objects: [PageObject]) -> Int {
        guard text.length > 0, size.width > 1, size.height > 1 else { return 0 }
        let layout = PageTextLayout(text: text, size: size, objects: objects)
        let remaining = max(0, text.length - layout.visibleCharacters)
        let endsWithBreak = (text.string as NSString).character(at: text.length - 1) == 10
        return remaining + (endsWithBreak && !layout.finalBlankLineFits ? 1 : 0)
    }

    private func apply(to view: UITextView, _ change: (NSMutableAttributedString) -> Void) {
        let candidate = NSMutableAttributedString(attributedString: view.attributedText)
        change(candidate)
        remember(view)
        view.textStorage.setAttributedString(candidate)
        notifyEdit(view)
    }

    static func contents(of page: Folio) -> NSAttributedString {
        let decoded = page.richText.flatMap {
            try? NSAttributedString(data: $0, options: [.documentType: NSAttributedString.DocumentType.rtfd],
                                    documentAttributes: nil)
        } ?? NSAttributedString(string: page.text, attributes: attributes)
        let result = NSMutableAttributedString(attributedString: decoded)
        let range = NSRange(location: 0, length: decoded.length)
        result.addAttribute(.foregroundColor, value: UIColor.label, range: range)
        decoded.enumerateAttribute(.font, in: range) { value, run, _ in
            let old = value as? UIFont ?? font
            let traits = old.fontDescriptor.symbolicTraits
            let base = traits.contains(.traitMonoSpace) ? old : typeface(
                (18...19).contains(old.pointSize) ? font.pointSize : old.pointSize, weight: traits.contains(.traitBold) ? .bold : .regular)
            let renderFont = traits.contains(.traitItalic)
                ? (UIFont(name: traits.contains(.traitBold) ? "Georgia-BoldItalic" : "Georgia-Italic",
                          size: base.pointSize) ?? base) : base
            result.addAttribute(.font, value: renderFont, range: run)
        }
        decoded.enumerateAttribute(.paragraphStyle, in: range) { value, run, _ in
            guard let style = value as? NSParagraphStyle, style.lineBreakMode != .byWordWrapping,
                  let adjusted = style.mutableCopy() as? NSMutableParagraphStyle else { return }
            adjusted.lineBreakMode = .byWordWrapping
            result.addAttribute(.paragraphStyle, value: adjusted, range: run)
        }
        return result
    }

    static func set(_ page: inout Folio, to value: NSAttributedString) throws {
        page.richText = value.length == 0 ? nil : try value.data(
            from: NSRange(location: 0, length: value.length),
            documentAttributes: [.documentType: NSAttributedString.DocumentType.rtfd])
        page.text = value.string
    }

    static func textView() -> UITextView {
        let view = UITextView(usingTextLayoutManager: false)
        view.backgroundColor = .clear
        view.textContainerInset = .zero
        view.textContainer.lineFragmentPadding = 0
        view.textContainer.lineBreakMode = .byWordWrapping
        view.contentInsetAdjustmentBehavior = .never
        view.font = font
        view.textColor = .label
        view.tintColor = .label
        return view
    }

    static func paths(_ objects: [PageObject], in size: CGSize) -> [UIBezierPath] {
        guard size.width > 0, size.height > 0 else { return [] }
        return objects.map { object in
            let rect = object.rect(in: size)
            let path = UIBezierPath(rect: CGRect(x: -rect.width / 2 - 7, y: -rect.height / 2 - 6,
                                                 width: rect.width + 14, height: rect.height + 12))
            path.apply(CGAffineTransform(rotationAngle: CGFloat(object.rotation ?? 0) * .pi / 180))
            path.apply(CGAffineTransform(translationX: rect.midX, y: rect.midY))
            return path
        }
    }

    private var formatSelection: NSRange?
    private var formatTyping: [NSAttributedString.Key: Any]?
    private var resumeKeyboard = false

    func beginFormatting() {
        guard let view else { return }
        formatSelection = view.selectedRange
        formatTyping = view.typingAttributes
        resumeKeyboard = view.isFirstResponder
        view.resignFirstResponder()
    }

    func endFormatting() {
        let selection = formatSelection
        let typing = formatTyping
        formatSelection = nil
        formatTyping = nil
        guard let view, let selection else { return }
        if resumeKeyboard { view.becomeFirstResponder() }
        view.selectedRange = selection
        if let typing { view.typingAttributes = typing }
        resumeKeyboard = false
    }

    private func select(in view: UITextView) -> NSRange {
        formatSelection ?? view.selectedRange
    }

    private func updateTyping(_ typing: [NSAttributedString.Key: Any], in view: UITextView) {
        if formatSelection != nil { formatTyping = typing }
        view.typingAttributes = typing
    }

    func applyTypeface(_ font: UIFont) {
        guard let view else { return }
        let selection = select(in: view)
        guard view.textStorage.length > 0 else { style(.font, value: font); return }
        let paragraph = (view.text as NSString).paragraphRange(for: selection)
        if paragraph.length > 0 {
            apply(to: view) { $0.addAttribute(.font, value: font, range: paragraph) }
            view.selectedRange = selection
        }
        var typing = formatTyping ?? view.typingAttributes
        typing[.font] = font
        typing[.foregroundColor] = UIColor.label
        updateTyping(typing, in: view)
    }

    func align(_ alignment: NSTextAlignment) {
        guard let view else { return }
        let paragraph = NSMutableParagraphStyle()
        paragraph.alignment = alignment
        let selection = select(in: view)
        let range = (view.text as NSString).paragraphRange(for: selection)
        if range.length > 0 {
            apply(to: view) { $0.addAttribute(.paragraphStyle, value: paragraph, range: range) }
            view.selectedRange = selection
        }
        var typing = formatTyping ?? view.typingAttributes
        typing[.paragraphStyle] = paragraph
        updateTyping(typing, in: view)
    }

    func style(_ key: NSAttributedString.Key, value: Any?) {
        guard let view else { return }
        let selection = select(in: view)
        if selection.length == 0 {
            var typing = formatTyping ?? view.typingAttributes
            typing[key] = value
            updateTyping(typing, in: view)
            if formatSelection == nil { view.becomeFirstResponder() }
            return
        }
        apply(to: view) { text in
            if let value { text.addAttribute(key, value: value, range: selection) }
            else { text.removeAttribute(key, range: selection) }
        }
        view.selectedRange = selection
        if formatSelection == nil { view.becomeFirstResponder() }
    }

    func current(_ key: NSAttributedString.Key) -> Any? {
        guard let view else { return nil }
        let range = select(in: view)
        if range.length > 0 { return view.textStorage.attribute(key, at: range.location, effectiveRange: nil) }
        return (formatTyping ?? view.typingAttributes)[key]
    }

    func fontTrait(_ trait: UIFontDescriptor.SymbolicTraits) {
        let font = current(.font) as? UIFont ?? Self.font
        let traits = font.fontDescriptor.symbolicTraits.symmetricDifference(trait)
        if font.familyName == "Georgia" {
            let bold = traits.contains(.traitBold)
            let italic = traits.contains(.traitItalic)
            let name = bold ? (italic ? "Georgia-BoldItalic" : "Georgia-Bold") : (italic ? "Georgia-Italic" : "Georgia")
            if let variant = UIFont(name: name, size: font.pointSize) {
                style(.font, value: variant)
                return
            }
        }
        if let descriptor = font.fontDescriptor.withSymbolicTraits(traits) {
            style(.font, value: UIFont(descriptor: descriptor, size: font.pointSize))
        }
    }

    func toggle(_ key: NSAttributedString.Key, value: Any) {
        style(key, value: current(key) == nil ? value : nil)
    }

    func insert(_ string: String) {
        insert(NSAttributedString(string: string, attributes: formatTyping ?? view?.typingAttributes ?? Self.attributes))
    }

    private func insert(_ text: NSAttributedString) {
        guard let view else { return }
        let selection = select(in: view)
        apply(to: view) { $0.replaceCharacters(in: selection, with: text) }
        let caret = NSRange(location: selection.location + text.length, length: 0)
        if formatSelection != nil { formatSelection = caret }
        view.selectedRange = caret
        if formatSelection == nil { view.becomeFirstResponder() }
    }

    private func remember(_ view: UITextView) {
        let snapshot = NSAttributedString(attributedString: view.attributedText)
        let selection = view.selectedRange
        view.undoManager?.registerUndo(withTarget: self) { document in
            MainActor.assumeIsolated {
                guard let editor = document.view, editor === view else { return }
                document.remember(editor)
                editor.attributedText = snapshot
                editor.selectedRange = selection
                document.notifyEdit(editor)
            }
        }
    }
}

extension Volume {
    func canvasSize(_ size: CGSize, at index: Int) -> CGSize {
        CGSize(width: size.width, height: max(40, size.height - (pages[index].chapter == nil ? 0 : 92)))
    }


}

struct PageEditor: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var phase
    @StateObject private var document = PageDocument()
    @State var book: Volume
    let pageSize: CGSize
    let save: (Volume) -> Bool
    @State private var photo: PhotosPickerItem?
    @State private var selectingPhoto = false
    @State private var photoTarget: UUID?
    @State private var pendingObject: PageObject?
    @State private var drafts: [UUID: NSAttributedString] = [:]
    @State private var revisions: [UUID: Int] = [:]
    @State private var visibleID: UUID?
    @State private var compositionID: UUID?
    @State private var viewport = CGRect.zero
    @State private var position = ScrollPosition(idType: UUID.self)
    @State private var focusRequest: FocusRequest?
    @State private var started = false
    private let separatorHeight: CGFloat = 32

    private struct FocusRequest: Equatable {
        let page: UUID
        let caret: Int
    }
    @State private var panel: Panel?
    @State private var problem = false
    @State private var arrangeAfterDrawing = false
    @State private var styleName = "Cuerpo"

    private enum Panel: String, Identifiable {
        case format, drawing, layout
        var id: String { rawValue }
    }

    private var visibleIndex: Int {
        book.pages.firstIndex { $0.id == visibleID } ?? book.position
    }

    private var visiblePage: Folio { book.pages[visibleIndex] }

    var body: some View {
        VStack(spacing: 12) {
            HStack(spacing: 10) {
                RoundControl(icon: "chevron.left", label: "Volver a leer", action: finish)
                VStack(alignment: .leading, spacing: 3) {
                    Text(book.title).font(.system(.headline, design: .serif)).lineLimit(1)
                    Label("Página \(visibleIndex + 1)", systemImage: "doc.text")
                        .font(.caption.weight(.semibold).monospacedDigit())
                        .contentTransition(.numericText())
                        .animation(.easeInOut(duration: 0.22), value: visibleIndex)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 3)
                        .background(.secondary.opacity(0.13), in: Capsule())
                }
                Spacer()
                RoundControl(icon: "arrow.uturn.backward", label: "Deshacer") {
                    document.view?.undoManager?.undo()
                }
                RoundControl(icon: "checkmark", label: "Listo", action: finish)
            }

            consecutivePages
            toolbar

            HStack {
                Button { changePage(-1) } label: { Label("Anterior", systemImage: "arrow.left") }
                    .disabled(visibleIndex == 0)
                Spacer()
                if !(visiblePage.objects ?? []).isEmpty {
                    RoundControl(icon: "arrow.up.left.and.arrow.down.right", label: "Colocar objetos") { arrange() }
                }
                Spacer()
                Button { changePage(1) } label: {
                    Label(visibleIndex + 1 == book.pages.count ? "Nueva página" : "Siguiente",
                          systemImage: visibleIndex + 1 == book.pages.count ? "plus" : "arrow.right")
                }
            }
            .buttonStyle(GlassButton())
        }
        .padding(.horizontal, 17)
        .padding(.top, 5)
        .padding(.bottom, 7)
        .background(ink.ignoresSafeArea())
        .foregroundStyle(paper)
        .interactiveDismissDisabled()
        .onChange(of: phase) { _, phase in if phase == .background { _ = store() } }
        .photosPicker(isPresented: $selectingPhoto, selection: $photo, matching: .images)
        .task(id: photo) {
            guard let photo, let destination = photoTarget else { return }
            let bytes = try? await photo.loadTransferable(type: Data.self)
            guard !Task.isCancelled else { return }
            defer {
                self.photo = nil
                photoTarget = nil
            }
            guard book.pages.contains(where: { $0.id == destination }) else { return }
            if let bytes, let data = photoData(bytes, maximum: 1400), let image = UIImage(data: data) {
                add(PageObject(kind: .photo, image: data, aspect: image.size.width / image.size.height), to: destination)
            } else { problem = true }
        }
        .sheet(item: $panel, onDismiss: {
            document.endFormatting()
            if arrangeAfterDrawing {
                arrangeAfterDrawing = false
                panel = .layout
            } else {
                pendingObject = nil
            }
        }) { panel in
            switch panel {
            case .format:
                formatPanel
                    .presentationDetents([.height(290), .medium])
            case .drawing:
                SketchSheet { image in
                    guard let data = image.pngData() else { return }
                    guard let compositionID else { return }
                    arrangeAfterDrawing = add(PageObject(kind: .drawing, image: data, aspect: image.size.width / image.size.height),
                                              to: compositionID, openLayout: false)
                }
            case .layout:
                if let compositionID, let index = book.pages.firstIndex(where: { $0.id == compositionID }) {
                    PlacementSheet(page: book.pages[index], size: book.canvasSize(pageSize, at: index),
                                   pending: pendingObject) { objects in
                        var updated = book
                        updated.pages[index].objects = objects
                        guard save(updated) else {
                            problem = true
                            return false
                        }
                        book = updated
                        return true
                    }
                }
            }
        }
        .alert("Relevant", isPresented: $problem) {
            Button("Entendido", role: .cancel) {}
        } message: {
            Text("No se pudo completar el cambio. Vuelve a intentarlo.")
        }
    }

    private var toolbar: some View {
        GeometryReader { geometry in
            let slot = geometry.size.width / 4
            HStack(spacing: 0) {
                Button {
                    activateToolbarPage()
                    document.beginFormatting()
                    panel = .format
                } label: {
                    Text("Aa").font(.headline)
                        .frame(maxWidth: .infinity)
                        .frame(height: 46)
                        .contentShape(Rectangle())
                }
                .accessibilityLabel("Formato")
                .frame(width: slot)

                icon("list.bullet", "Viñeta", height: 46) { activateToolbarPage(); document.insert("• ") }
                    .frame(width: slot)

                Button {
                    photoTarget = visiblePage.id
                    selectingPhoto = true
                } label: {
                    Image(systemName: "photo")
                        .frame(maxWidth: .infinity)
                        .frame(height: 46)
                        .contentShape(Rectangle())
                }
                .accessibilityLabel("Insertar foto")
                .frame(width: slot)

                icon("pencil.tip", "Dibujo", height: 46) {
                    compositionID = visiblePage.id
                    panel = .drawing
                }
                    .frame(width: slot)
            }
            .font(.system(size: 19))
            .buttonStyle(.plain)
        }
        .frame(height: 46)
        .background { Capsule().fill(.clear).modifier(GlassSurface(shape: Capsule())).allowsHitTesting(false) }
    }

    private var formatPanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("Formato").font(.title2.weight(.semibold))
                Spacer()
                RoundControl(icon: "xmark", label: "Cerrar formato") { panel = nil }
            }
            ScrollView(.horizontal) {
                HStack(spacing: 6) {
                    format("Título", font: PageDocument.typeface(30, weight: .bold))
                    format("Encabezado", font: PageDocument.typeface(25, weight: .bold))
                    format("Subtítulo", font: PageDocument.typeface(21, weight: .bold))
                    format("Cuerpo", font: PageDocument.font)
                    format("Monoespaciado", font: .monospacedSystemFont(ofSize: 18, weight: .regular))
                }
                .padding(5)
            }
            .scrollIndicators(.hidden)
            .background { Capsule().fill(.clear).modifier(GlassSurface(shape: Capsule())).allowsHitTesting(false) }
            HStack {
                icon("bold", "Negrita") { document.fontTrait(.traitBold) }
                icon("italic", "Cursiva") { document.fontTrait(.traitItalic) }
                icon("underline", "Subrayado") { document.toggle(.underlineStyle, value: 1) }
                icon("strikethrough", "Tachado") { document.toggle(.strikethroughStyle, value: 1) }
                icon("highlighter", "Resaltar") {
                    document.toggle(.backgroundColor, value: UIColor.systemGray.withAlphaComponent(0.35))
                }
            }
            .background { Capsule().fill(.clear).modifier(GlassSurface(shape: Capsule())).allowsHitTesting(false) }
            HStack {
                icon("list.bullet", "Viñeta") { document.insert("• "); panel = nil }
                icon("list.number", "Lista numerada") { document.insert("1. "); panel = nil }
                icon("text.alignleft", "Alinear a la izquierda") { document.align(.left) }
                icon("text.aligncenter", "Centrar texto") { document.align(.center) }
                icon("text.alignright", "Alinear a la derecha") { document.align(.right) }
            }
            .background { Capsule().fill(.clear).modifier(GlassSurface(shape: Capsule())).allowsHitTesting(false) }
        }
        .buttonStyle(.plain)
        .foregroundStyle(paper)
        .padding(18)
    }

    private func format(_ name: String, font: UIFont) -> some View {
        Button {
            styleName = name
            document.applyTypeface(font)
        } label: {
            Text(name).font(.custom(font.fontName, size: font.pointSize)).lineLimit(1).padding(.horizontal, 12).frame(height: 38)
                .background(paper.opacity(styleName == name ? 0.16 : 0), in: Capsule())
        }
    }

    private func icon(_ symbol: String, _ title: String, height: CGFloat = 44, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol).frame(maxWidth: .infinity).frame(height: height)
                .contentShape(Rectangle())
        }
        .accessibilityLabel(title)
    }

    private var consecutivePages: some View {
        ScrollView {
            LazyVStack(spacing: 0) {
                ForEach(Array(book.pages.enumerated()), id: \.element.id) { index, page in
                    editorPage(page, at: index)
                        .id(page.id)
                }
            }
            .scrollTargetLayout()
        }
        .scrollPosition($position)
        .scrollDismissesKeyboard(.interactively)
        .onScrollGeometryChange(for: CGRect.self, of: { $0.visibleRect }) { old, rect in
            viewport = rect
            guard started else { return }
            updateVisiblePage(rect)
            if rect.height < old.height, let editor = document.view, let activePage = document.activePage,
               let index = book.pages.firstIndex(where: { $0.id == activePage }) {
                revealCaret(in: editor, at: index)
            }
        }
        .task {
            document.onEdit = receiveEdit
            guard !started else { return }
            let initial = book.pages[book.position].id
            visibleID = initial
            position.scrollTo(id: initial, anchor: .top)
            started = true
        }
    }

    private func editorPage(_ page: Folio, at index: Int) -> some View {
        let canvas = book.canvasSize(pageSize, at: index)
        return VStack(spacing: 0) {
            HStack(spacing: 10) {
                Rectangle().fill(.secondary.opacity(0.15)).frame(height: 1)
                Text("-\(index + 1)-")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary.opacity(0.7))
                    .accessibilityLabel("Página \(index + 1)")
                Rectangle().fill(.secondary.opacity(0.15)).frame(height: 1)
            }
            .frame(height: separatorHeight)

            if let chapter = page.chapter {
                VStack(spacing: 4) {
                    Text(book.chapterNumber(at: index))
                        .font(.system(size: 14, weight: .semibold, design: .serif)).tracking(3)
                    Text(chapter)
                        .font(.system(size: 29, weight: .semibold, design: .serif))
                        .lineLimit(2)
                        .minimumScaleFactor(0.65)
                }
                .multilineTextAlignment(.center)
                .frame(width: canvas.width, height: 92)
                .accessibilityAddTraits(.isHeader)
            }

            ZStack(alignment: .topLeading) {
                WritingSurface(page: page, text: drafts[page.id], document: document, canvas: canvas,
                               focusAt: focusRequest?.page == page.id ? focusRequest?.caret : nil) { editor in
                    if focusRequest?.page == page.id { focusRequest = nil }
                    if let current = book.pages.firstIndex(where: { $0.id == page.id }) {
                        revealCaret(in: editor, at: current)
                    }
                }
                    .id(revisions[page.id, default: 0])
                    .frame(width: canvas.width, height: canvas.height)
                ForEach(page.objects ?? []) { object in
                    let rect = object.rect(in: canvas)
                    ObjectView(object: object)
                        .frame(width: rect.width, height: rect.height)
                        .rotationEffect(.degrees(object.rotation ?? 0))
                        .position(x: rect.midX, y: rect.midY)
                        .allowsHitTesting(false)
                        .accessibilityHidden(true)
                }
            }
            .frame(width: canvas.width, height: canvas.height)
            .clipped()
        }
        .frame(width: canvas.width)
        .frame(maxWidth: .infinity)
    }

    private func height(at index: Int) -> CGFloat {
        separatorHeight + book.canvasSize(pageSize, at: index).height + chapterHeight(at: index)
    }

    private func chapterHeight(at index: Int) -> CGFloat {
        book.pages[index].chapter == nil ? 0 : 92
    }

    private func updateVisiblePage(_ rect: CGRect) {
        guard rect.height > 0 else { return }
        var offset: CGFloat = 0
        var best: CGFloat = 0
        var mostVisible = visibleID
        for index in book.pages.indices {
            let bottom = offset + height(at: index)
            let shown = max(0, min(bottom, rect.maxY) - max(offset + separatorHeight, rect.minY))
            if shown > best {
                best = shown
                mostVisible = book.pages[index].id
            }
            offset = bottom
            if offset >= rect.maxY { break }
        }
        if visibleID != mostVisible { visibleID = mostVisible }
    }

    private func activateToolbarPage() {
        if document.view?.isFirstResponder != true { document.activate(visiblePage.id) }
    }

    @discardableResult
    private func add(_ object: PageObject, to pageID: UUID, openLayout: Bool = true) -> Bool {
        document.view?.resignFirstResponder()
        guard store() else { return false }
        compositionID = pageID
        pendingObject = object
        if openLayout { panel = .layout }
        return true
    }

    private func arrange() {
        compositionID = visiblePage.id
        document.view?.resignFirstResponder()
        if store() { panel = .layout }
    }

    private func receiveEdit(_ id: UUID, _ editor: UITextView) {
        guard editor.markedTextRange == nil,
              let index = book.pages.firstIndex(where: { $0.id == id }) else { return }
        let candidate = NSAttributedString(attributedString: editor.attributedText)
        let canvas = book.canvasSize(pageSize, at: index)
        let objects = book.pages[index].objects ?? []
        let selection = editor.selectedRange.location
        let previous = drafts[id] ?? PageDocument.contents(of: book.pages[index])
        guard PageDocument.overflow(candidate, in: canvas, objects: objects) > 0 else {
            drafts[id] = candidate
            revealCaret(in: editor, at: index)
            return
        }

        var updated = book
        var distributed = drafts
        var changed: [UUID] = []
        var text = candidate
        var pageIndex = index
        var caret = selection
        var destination = id
        var destinationCaret = selection
        var foundCaret = false

        while true {
            let page = updated.pages[pageIndex]
            let size = updated.canvasSize(pageSize, at: pageIndex)
            let layout = PageTextLayout(text: text, size: size, objects: page.objects ?? [])
            let string = text.string as NSString
            var boundary = min(text.length, layout.visibleCharacters)
            if boundary > 0 && boundary < text.length {
                let last = string.rangeOfComposedCharacterSequence(at: boundary - 1)
                if NSMaxRange(last) > boundary { boundary = last.location }
            }
            let needsBlankPage = boundary == text.length && text.length > 0
                && string.character(at: text.length - 1) == 10 && !layout.finalBlankLineFits
            let continues = boundary < text.length || needsBlankPage
            if boundary == 0 && pageIndex > index && continues
                && page.chapter == nil && (page.objects ?? []).isEmpty {
                // A single attachment or glyph can be taller than any page.
                editor.attributedText = previous
                editor.selectedRange = NSRange(location: min(selection, previous.length), length: 0)
                problem = true
                return
            }
            let end = needsBlankPage ? boundary - 1 : boundary
            distributed[page.id] = text.attributedSubstring(from: NSRange(location: 0, length: end))
            changed.append(page.id)
            if !foundCaret && (!continues || caret <= end) {
                foundCaret = true
                destination = page.id
                destinationCaret = min(caret, end)
            }
            guard continues else { break }

            caret = max(0, caret - boundary)
            text = text.attributedSubstring(from: NSRange(location: boundary, length: text.length - boundary))
            pageIndex += 1
            if pageIndex == updated.pages.count {
                updated.pages.append(Folio())
            } else {
                let next = updated.pages[pageIndex]
                let existing = distributed[next.id] ?? PageDocument.contents(of: next)
                if existing.length > 0 {
                    let joined = NSMutableAttributedString(attributedString: text)
                    if text.length > 0, !text.string.hasSuffix("\n"), !existing.string.hasPrefix("\n") {
                        var attributes = text.attributes(at: text.length - 1, effectiveRange: nil)
                        attributes.removeValue(forKey: .attachment)
                        joined.append(NSAttributedString(string: "\n", attributes: attributes))
                    }
                    joined.append(existing)
                    text = joined
                }
            }
        }

        book = updated
        drafts = distributed
        for page in changed { revisions[page, default: 0] += 1 }
        if editor.isFirstResponder { focusRequest = FocusRequest(page: destination, caret: destinationCaret) }
        if destination != id {
            visibleID = destination
            position.scrollTo(id: destination, anchor: .top)
        }
    }

    private func revealCaret(in editor: UITextView, at index: Int) {
        guard editor.isFirstResponder, viewport.height > 0, let selection = editor.selectedTextRange else { return }
        let offset = book.pages.indices.prefix(index).reduce(CGFloat(0)) { $0 + height(at: $1) }
        let caret = editor.caretRect(for: selection.end).offsetBy(dx: 0, dy: offset + separatorHeight + chapterHeight(at: index))
        if caret.maxY + 18 > viewport.maxY {
            position.scrollTo(y: max(0, caret.maxY + 18 - viewport.height))
        } else if caret.minY < viewport.minY {
            position.scrollTo(y: max(0, caret.minY - 12))
        }
    }

    private func store() -> Bool {
        if let editor = document.view, let activePage = document.activePage, editor.markedTextRange != nil {
            editor.unmarkText()
            receiveEdit(activePage, editor)
        }
        var updated = book
        updated.position = visibleIndex
        do {
            for index in updated.pages.indices {
                if let text = drafts[updated.pages[index].id] {
                    try PageDocument.set(&updated.pages[index], to: text)
                }
            }
        } catch {
            problem = true
            return false
        }
        guard save(updated) else { problem = true; return false }
        book = updated
        drafts.removeAll()
        return true
    }

    private func changePage(_ offset: Int) {
        let target = visibleIndex + offset
        guard target >= 0 else { return }
        if target == book.pages.count { book.pages.append(Folio()) }
        let id = book.pages[target].id
        visibleID = id
        position.scrollTo(id: id, anchor: .top)
    }

    private func finish() {
        if store() { dismiss() }
    }
}

struct WritingSurface: UIViewRepresentable {
    let page: Folio
    let text: NSAttributedString?
    let document: PageDocument
    let canvas: CGSize
    let focusAt: Int?
    let onFocusApplied: (UITextView) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(document: document, page: page.id) }

    func makeUIView(context: Context) -> EditorViewport {
        let view = PageDocument.textView()
        let host = EditorViewport(editor: view)
        view.frame = CGRect(origin: .zero, size: canvas)
        view.textContainer.widthTracksTextView = true
        view.textContainer.heightTracksTextView = false
        view.textContainer.size = CGSize(width: canvas.width, height: .greatestFiniteMagnitude)
        view.isScrollEnabled = false
        view.attributedText = text ?? PageDocument.contents(of: page)
        view.textContainer.exclusionPaths = PageDocument.paths(page.objects ?? [], in: canvas)
        view.typingAttributes = PageDocument.attributes
        view.accessibilityLabel = "Texto de la página"
        view.delegate = context.coordinator
        document.register(view, for: page.id)
        return host
    }

    func sizeThatFits(_ proposal: ProposedViewSize, uiView: EditorViewport, context: Context) -> CGSize? { canvas }

    func updateUIView(_ host: EditorViewport, context: Context) {
        let coordinator = context.coordinator
        let view = host.editor
        if coordinator.objects != page.objects || coordinator.canvas != canvas {
            coordinator.objects = page.objects
            coordinator.canvas = canvas
            view.textContainer.exclusionPaths = PageDocument.paths(page.objects ?? [], in: canvas)
        }
        if coordinator.focusAt != focusAt {
            coordinator.focusAt = focusAt
            if let focusAt {
                DispatchQueue.main.async { [weak view] in
                    guard let view, view.window != nil, coordinator.focusAt == focusAt else { return }
                    view.becomeFirstResponder()
                    let offset = min(focusAt, view.textStorage.length)
                    view.selectedRange = NSRange(location: offset, length: 0)
                    if offset > 0 {
                        view.typingAttributes = view.textStorage.attributes(at: offset - 1, effectiveRange: nil)
                    }
                    onFocusApplied(view)
                }
            }
        }
    }

    final class Coordinator: NSObject, UITextViewDelegate {
        let document: PageDocument
        let page: UUID
        var objects: [PageObject]?
        var canvas = CGSize.zero
        var focusAt: Int?

        init(document: PageDocument, page: UUID) {
            self.document = document
            self.page = page
        }

        func textViewDidBeginEditing(_ textView: UITextView) {
            document.activate(page)
        }

        func textViewDidChange(_ textView: UITextView) {
            document.onEdit(page, textView)
        }
    }
}

final class EditorViewport: UIView {
    let editor: UITextView

    init(editor: UITextView) {
        self.editor = editor
        super.init(frame: .zero)
        clipsToBounds = true
        addSubview(editor)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("Use init(editor:)") }

    override func layoutSubviews() {
        super.layoutSubviews()
        editor.frame = bounds
        // A saved paragraph can be loaded before SwiftUI assigns the final bounds.
        // Give TextKit the actual viewport width again after the first layout.
        let container = editor.textContainer
        if bounds.width > 0, abs(container.size.width - bounds.width) > 0.5 {
            container.size = CGSize(width: bounds.width, height: .greatestFiniteMagnitude)
        }
    }
}

struct SketchSheet: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var scheme
    @State private var sketch = PKDrawing()
    let insert: (UIImage) -> Void

    var body: some View {
        VStack {
            HStack {
                Button("Cancelar") { dismiss() }
                Spacer()
                Text("Dibujo").font(.system(.title3, design: .serif))
                Spacer()
                Button("Insertar") {
                    let bounds = sketch.bounds.insetBy(dx: -8, dy: -8)
                    insert(sketch.image(from: bounds, scale: 1))
                    dismiss()
                }
                .disabled(sketch.strokes.isEmpty)
            }
            .buttonStyle(GlassButton())
            .padding()
            SketchCanvas(sketch: $sketch, dark: scheme == .dark)
        }
        .foregroundStyle(paper)
        .background(ink.ignoresSafeArea())
    }
}

struct SketchCanvas: UIViewRepresentable {
    @Binding var sketch: PKDrawing
    var dark: Bool

    func makeCoordinator() -> Coordinator { Coordinator(sketch: $sketch) }

    func makeUIView(context: Context) -> PKCanvasView {
        let canvas = PKCanvasView()
        canvas.backgroundColor = dark ? .black : .white
        canvas.drawingPolicy = .anyInput
        canvas.tool = PKInkingTool(.pen, color: dark ? .white : .black, width: 4)
        canvas.delegate = context.coordinator
        canvas.isScrollEnabled = false
        canvas.accessibilityLabel = "Lienzo de dibujo"
        return canvas
    }

    func updateUIView(_ canvas: PKCanvasView, context: Context) {}

    final class Coordinator: NSObject, PKCanvasViewDelegate {
        var sketch: Binding<PKDrawing>

        init(sketch: Binding<PKDrawing>) { self.sketch = sketch }

        func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
            sketch.wrappedValue = canvasView.drawing
        }
    }
}

struct ObjectView: View {
    let object: PageObject
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        GeometryReader { geometry in
            if let cells = object.cells, object.kind == .table {
                let columns = max(cells.first?.count ?? 1, 1)
                let cellWidth = geometry.size.width / CGFloat(columns)
                let cellHeight = geometry.size.height / CGFloat(max(1, cells.count))
                VStack(spacing: 0) {
                    ForEach(cells.indices, id: \.self) { row in
                        HStack(spacing: 0) {
                            ForEach(cells[row].indices, id: \.self) { column in
                                Text(cells[row][column])
                                    .font(.system(size: 12, weight: row == 0 ? .semibold : .regular))
                                    .padding(3).lineLimit(3).minimumScaleFactor(0.72)
                                    .frame(width: cellWidth, height: cellHeight)
                                    .background(row == 0 ? paper.opacity(0.08) : ink)
                                    .overlay { Rectangle().strokeBorder(paper.opacity(0.24), lineWidth: 0.5) }
                            }
                        }
                    }
                }
                .clipped()
                .accessibilityLabel("Tabla")
            } else if let data = object.image, let image = UIImage(data: data) {
                if object.kind == .drawing {
                    Image(uiImage: image).renderingMode(.template).resizable().scaledToFit()
                        .foregroundStyle(scheme == .dark ? .white : .black)
                        .accessibilityLabel("Dibujo")
                } else {
                    Image(uiImage: image).resizable().scaledToFit().accessibilityLabel("Foto")
                }
            }
        }
    }
}

struct PlacementSheet: View {
    @Environment(\.dismiss) private var dismiss
    @State private var objects: [PageObject]
    @State private var selected: UUID?
    @State private var dragOrigin: CGPoint?
    @State private var pinchWidth: Double?
    @State private var rotationStart: Double?
    @State private var editingTable = false
    let page: Folio
    let size: CGSize
    let save: ([PageObject]) -> Bool
    @State private var lastChanged: UUID?
    private let text: NSAttributedString

    init(page: Folio, size: CGSize, pending: PageObject?, save: @escaping ([PageObject]) -> Bool) {
        self.page = page
        self.size = size
        self.save = save
        self.text = PageDocument.contents(of: page)
        let additions = pending.map { [$0] } ?? []
        _objects = State(initialValue: (page.objects ?? []) + additions)
        _selected = State(initialValue: pending?.id ?? page.objects?.last?.id)
        _lastChanged = State(initialValue: pending?.id)
    }

    private var index: Int? { objects.firstIndex { $0.id == selected } }

    var body: some View {
        let overflowing = PageDocument.overflow(text, in: size, objects: objects) > 0
        let invalid = Set(objects.filter { !$0.fitsInside(size) }.map(\.id))
        let affected = lastChanged ?? selected
        let canApply = !overflowing && invalid.isEmpty
        VStack(spacing: 12) {
            HStack {
                RoundControl(icon: "xmark", label: "Cancelar") { dismiss() }
                Spacer()
                Text("Composición").font(.system(.title3, design: .serif))
                Spacer()
                RoundControl(icon: "checkmark", label: "Aplicar composición") {
                    if canApply, save(objects) { dismiss() }
                }
                .disabled(!canApply)
                .opacity(canApply ? 1 : 0.45)
            }
            GeometryReader { geometry in
                let scale = max(0.05, min(geometry.size.width / max(size.width, 1),
                                          geometry.size.height / max(size.height, 1)))
                ZStack(alignment: .topLeading) {
                    let fitting = objects.filter { !invalid.contains($0.id) && !(overflowing && $0.id == affected) }
                    let draft = Folio(text: page.text, richText: page.richText, objects: fitting)
                    PageText(page: draft, size: size).frame(width: size.width, height: size.height)
                        .allowsHitTesting(false)
                    ForEach(objects) { object in
                        let rect = object.rect(in: size)
                        ObjectView(object: object)
                            .frame(width: rect.width, height: rect.height)
                            .overlay {
                                if invalid.contains(object.id) || (overflowing && object.id == affected) {
                                    ZStack {
                                        Rectangle().fill(.red.opacity(0.26))
                                        Rectangle().strokeBorder(.red, lineWidth: 2)
                                        Image(systemName: "xmark.circle.fill")
                                            .font(.title2).foregroundStyle(.red)
                                            .background(.white, in: Circle())
                                    }
                                    .allowsHitTesting(false)
                                } else if object.id == selected {
                                    Rectangle().strokeBorder(paper.opacity(0.7),
                                                             style: StrokeStyle(lineWidth: 1, dash: [4, 3]))
                                }
                            }
                            .contentShape(Rectangle())
                            .rotationEffect(.degrees(object.rotation ?? 0))
                            .onTapGesture { selected = object.id }
                            .gesture(move(object))
                            .simultaneousGesture(resize(object), including: object.isFreeformArtwork ? .all : .none)
                            .simultaneousGesture(rotate(object), including: object.isFreeformArtwork ? .all : .none)
                            .position(x: rect.midX, y: rect.midY)
                    }
                }
                .frame(width: size.width, height: size.height)
                .coordinateSpace(name: "placement")
                .background(ink)
                .clipped()
                .overlay { Rectangle().strokeBorder(paper.opacity(0.16)).allowsHitTesting(false) }
                .scaleEffect(scale)
                .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
            }
            if !canApply {
                Text("El objeto no cabe. Redúcelo o muévelo para dejar espacio al texto.")
                    .font(.footnote)
                    .foregroundStyle(.red)
            }
            if let index {
                HStack(spacing: 15) {
                    Slider(value: $objects[index].width, in: objects[index].isFreeformArtwork ? 0.08...2.0 : 0.16...0.96) { Text("Tamaño") }
                        .onChange(of: objects[index].width) { _, _ in lastChanged = selected }
                    if objects[index].kind == .table {
                        RoundControl(icon: "tablecells", label: "Editar celdas") { editingTable = true }
                    }
                    RoundControl(icon: "trash", label: "Quitar objeto de la página") {
                        objects.remove(at: index)
                        selected = objects.last?.id
                    }
                }
            }
        }
        .padding(18)
        .foregroundStyle(paper)
        .background(ink.ignoresSafeArea())
        .sheet(isPresented: $editingTable) {
            if let index, let cells = objects[index].cells {
                let id = objects[index].id
                TableSheet(cells: cells) { newCells in
                    guard let match = objects.firstIndex(where: { $0.id == id }) else { return }
                    objects[match].cells = newCells
                    objects[match].aspect = Double(newCells[0].count) * 1.8 / Double(newCells.count)
                }
            }
        }
    }

    private func move(_ object: PageObject) -> some Gesture {
        DragGesture(minimumDistance: 4, coordinateSpace: .named("placement"))
            .onChanged { drag in
                guard let i = objects.firstIndex(where: { $0.id == object.id }) else { return }
                selected = object.id
                lastChanged = object.id
                if dragOrigin == nil {
                    let rect = objects[i].rect(in: size)
                    dragOrigin = CGPoint(x: rect.midX, y: rect.midY)
                }
                guard let origin = dragOrigin else { return }
                if object.isFreeformArtwork, objects[i].usesFreePosition != true {
                    let frame = objects[i].rect(in: size)
                    objects[i].width = Double(min(frame.width, frame.height * objects[i].aspect) / size.width)
                    enableFreePosition(at: i, frame: frame)
                }
                objects[i].x = min(1, max(0, (origin.x + drag.translation.width) / size.width))
                objects[i].y = min(1, max(0, (origin.y + drag.translation.height) / size.height))
            }
            .onEnded { _ in dragOrigin = nil }
    }

    private func resize(_ object: PageObject) -> some Gesture {
        MagnifyGesture()
            .onChanged { gesture in
                guard let i = objects.firstIndex(where: { $0.id == object.id }) else { return }
                selected = object.id
                lastChanged = object.id
                if pinchWidth == nil {
                    let frame = objects[i].rect(in: size)
                    pinchWidth = Double(min(frame.width, frame.height * objects[i].aspect) / size.width)
                    enableFreePosition(at: i, frame: frame)
                }
                guard let pinchWidth else { return }
                objects[i].width = min(2, max(0.08, pinchWidth * Double(gesture.magnification)))
            }
            .onEnded { _ in pinchWidth = nil }
    }

    private func rotate(_ object: PageObject) -> some Gesture {
        RotateGesture()
            .onChanged { gesture in
                guard let i = objects.firstIndex(where: { $0.id == object.id }) else { return }
                selected = object.id
                lastChanged = object.id
                if rotationStart == nil { rotationStart = objects[i].rotation ?? 0 }
                guard let rotationStart else { return }
                objects[i].rotation = (rotationStart + gesture.rotation.degrees).truncatingRemainder(dividingBy: 360)
            }
            .onEnded { _ in rotationStart = nil }
    }

    private func enableFreePosition(at index: Int, frame: CGRect) {
        guard objects[index].usesFreePosition != true else { return }
        objects[index].x = frame.midX / size.width
        objects[index].y = frame.midY / size.height
        objects[index].usesFreePosition = true
    }

}

struct TableSheet: View {
    @Environment(\.dismiss) private var dismiss
    @State var cells: [[String]]
    let save: ([[String]]) -> Void

    var body: some View {
        VStack(spacing: 15) {
            HStack {
                RoundControl(icon: "xmark", label: "Cancelar") { dismiss() }
                Spacer()
                Text("Tabla").font(.system(.title3, design: .serif))
                Spacer()
                RoundControl(icon: "checkmark", label: "Guardar celdas") { save(cells); dismiss() }
            }
            ScrollView([.horizontal, .vertical]) {
                VStack(alignment: .leading, spacing: 1) {
                    ForEach(cells.indices, id: \.self) { row in
                        HStack(spacing: 1) {
                            ForEach(cells[row].indices, id: \.self) { column in
                                TextField("Celda", text: $cells[row][column], axis: .vertical)
                                    .accessibilityLabel("Fila \(row + 1), columna \(column + 1)")
                                    .padding(9)
                                    .frame(width: 115, alignment: .leading)
                                    .background(paper.opacity(0.08))
                            }
                        }
                    }
                }
            }
            HStack {
                Button("Añadir fila") { cells.append(Array(repeating: "", count: cells[0].count)) }
                    .disabled(cells.count >= 8)
                Button("Añadir columna") {
                    for index in cells.indices { cells[index].append("") }
                }
                .disabled(cells[0].count >= 6)
            }
            .buttonStyle(GlassButton())
        }
        .padding(18)
        .foregroundStyle(paper)
        .background(ink.ignoresSafeArea())
    }
}
