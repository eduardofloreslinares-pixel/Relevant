import SwiftUI
import PhotosUI
import PencilKit
import UIKit

@MainActor
final class PageDocument: ObservableObject {
    static func typeface(_ size: CGFloat, weight: UIFont.Weight = .regular) -> UIFont {
        let base = UIFont.systemFont(ofSize: size, weight: weight)
        return UIFont(name: weight == .regular ? "Georgia" : "Georgia-Bold", size: size) ?? base
    }
    static let font = typeface(18)
    static let attributes: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: UIColor.label]
    weak var view: UITextView?

    static func contents(of page: Folio) -> NSAttributedString {
        let decoded = page.richText.flatMap {
            try? NSAttributedString(data: $0, options: [.documentType: NSAttributedString.DocumentType.rtfd],
                                    documentAttributes: nil)
        } ?? NSAttributedString(string: page.text, attributes: attributes)
        let result = NSMutableAttributedString(attributedString: decoded)
        let range = NSRange(location: 0, length: decoded.length)
        result.addAttribute(.foregroundColor, value: UIColor.label, range: range)
        decoded.enumerateAttribute(.font, in: range) { value, run, _ in
            let old = value as? UIFont ?? font
            let traits = old.fontDescriptor.symbolicTraits
            let base = traits.contains(.traitMonoSpace) ? old : typeface(
                old.pointSize == 19 ? 18 : old.pointSize, weight: traits.contains(.traitBold) ? .bold : .regular)
            let renderFont = traits.contains(.traitItalic)
                ? (UIFont(name: traits.contains(.traitBold) ? "Georgia-BoldItalic" : "Georgia-Italic",
                          size: base.pointSize) ?? base) : base
            result.addAttribute(.font, value: renderFont, range: run)
        }
        return result
    }

    static func set(_ page: inout Folio, to value: NSAttributedString) throws {
        page.richText = value.length == 0 ? nil : try value.data(
            from: NSRange(location: 0, length: value.length),
            documentAttributes: [.documentType: NSAttributedString.DocumentType.rtfd])
        page.text = value.string
    }

    static func moveInlineImages(in text: NSAttributedString, into page: inout Folio) -> NSAttributedString {
        let copy = NSMutableAttributedString(attributedString: text)
        var objects = page.objects ?? []
        let entireText = NSRange(location: 0, length: text.length)
        text.enumerateAttribute(.attachment, in: entireText, options: .reverse) { value, range, _ in
            guard let attachment = value as? NSTextAttachment else { return }
            let stored = attachment.fileWrapper?.regularFileContents.flatMap { UIImage(data: $0) }
            guard let image = attachment.image ?? stored, image.size.width > 0, image.size.height > 0,
                  let data = image.pngData() else { return }
            let index = objects.count
            let x = index.isMultiple(of: 2) ? 0.24 : 0.76
            let y = min(0.84, 0.32 + Double(index / 2) * 0.24)
            objects.append(PageObject(kind: .photo, image: data, x: x, y: y,
                                      width: 0.36, aspect: image.size.width / image.size.height))
            copy.deleteCharacters(in: range)
        }
        if !objects.isEmpty { page.objects = objects }
        return copy
    }

    static func textView() -> UITextView {
        let view = UITextView(usingTextLayoutManager: false)
        view.backgroundColor = .clear
        view.textContainerInset = .zero
        view.textContainer.lineFragmentPadding = 0
        view.font = font
        view.textColor = .label
        view.tintColor = .label
        return view
    }

    static func paths(_ objects: [PageObject], in size: CGSize) -> [UIBezierPath] {
        guard size.width > 0, size.height > 0 else { return [] }
        return objects.map { UIBezierPath(rect: $0.rect(in: size).insetBy(dx: -7, dy: -6)) }
    }

    static func splitPoint(_ text: NSAttributedString, in size: CGSize, objects: [PageObject]) -> Int {
        guard text.length > 0, size.width > 1, size.height > 1 else { return text.length }
        let storage = NSTextStorage(attributedString: text)
        let layout = NSLayoutManager()
        let container = NSTextContainer(size: CGSize(width: size.width, height: 10_000_000))
        container.lineFragmentPadding = 0
        container.exclusionPaths = paths(objects, in: size)
        storage.addLayoutManager(layout)
        layout.addTextContainer(container)
        layout.ensureLayout(forBoundingRect: CGRect(x: 0, y: 0, width: size.width, height: size.height + 2), in: container)
        let measured = layout.glyphRange(forBoundingRect: CGRect(x: 0, y: 0, width: size.width,
                                                                 height: size.height + 1), in: container)
        guard measured.length > 0 else { return 0 }
        var end = 0
        layout.enumerateLineFragments(forGlyphRange: measured) { rect, used, _, glyphs, stop in
            guard max(rect.maxY, used.maxY) <= size.height + 0.5 else {
                stop.pointee = true
                return
            }
            end = NSMaxRange(layout.characterRange(forGlyphRange: glyphs, actualGlyphRange: nil))
        }
        return min(end, text.length)
    }

    func applyTypeface(_ font: UIFont) {
        guard let view else { return }
        let selection = view.selectedRange
        guard view.textStorage.length > 0 else { style(.font, value: font); return }
        let paragraph = (view.text as NSString).paragraphRange(for: selection)
        if paragraph.length > 0 {
            remember(view)
            view.textStorage.addAttribute(.font, value: font, range: paragraph)
            view.selectedRange = selection
        }
        var typing = view.typingAttributes
        typing[.font] = font
        typing[.foregroundColor] = UIColor.label
        view.typingAttributes = typing
    }

    func align(_ alignment: NSTextAlignment) {
        guard let view else { return }
        let paragraph = NSMutableParagraphStyle()
        paragraph.alignment = alignment
        let selection = view.selectedRange
        let range = (view.text as NSString).paragraphRange(for: selection)
        guard range.length > 0 else { style(.paragraphStyle, value: paragraph); return }
        remember(view)
        view.textStorage.addAttribute(.paragraphStyle, value: paragraph, range: range)
        view.selectedRange = selection
    }

    func style(_ key: NSAttributedString.Key, value: Any?) {
        guard let view else { return }
        let selection = view.selectedRange
        if selection.length == 0 {
            var typing = view.typingAttributes
            typing[key] = value
            view.typingAttributes = typing
            view.becomeFirstResponder()
            return
        }
        remember(view)
        if let value { view.textStorage.addAttribute(key, value: value, range: selection) }
        else { view.textStorage.removeAttribute(key, range: selection) }
        view.selectedRange = selection
        view.becomeFirstResponder()
    }

    func current(_ key: NSAttributedString.Key) -> Any? {
        guard let view else { return nil }
        let range = view.selectedRange
        if range.length > 0 { return view.textStorage.attribute(key, at: range.location, effectiveRange: nil) }
        return view.typingAttributes[key]
    }

    func fontTrait(_ trait: UIFontDescriptor.SymbolicTraits) {
        let font = current(.font) as? UIFont ?? Self.font
        let traits = font.fontDescriptor.symbolicTraits.symmetricDifference(trait)
        if let descriptor = font.fontDescriptor.withSymbolicTraits(traits) {
            style(.font, value: UIFont(descriptor: descriptor, size: font.pointSize))
        }
    }

    func toggle(_ key: NSAttributedString.Key, value: Any) {
        style(key, value: current(key) == nil ? value : nil)
    }

    func insert(_ string: String) {
        insert(NSAttributedString(string: string, attributes: view?.typingAttributes ?? Self.attributes))
    }

    private func insert(_ text: NSAttributedString) {
        guard let view else { return }
        let selection = view.selectedRange
        remember(view)
        view.textStorage.replaceCharacters(in: selection, with: text)
        view.selectedRange = NSRange(location: selection.location + text.length, length: 0)
        view.becomeFirstResponder()
    }

    private func remember(_ view: UITextView) {
        let snapshot = NSAttributedString(attributedString: view.attributedText)
        let selection = view.selectedRange
        view.undoManager?.registerUndo(withTarget: self) { document in
            MainActor.assumeIsolated {
                guard let editor = document.view, editor === view else { return }
                document.remember(editor)
                editor.attributedText = snapshot
                editor.selectedRange = selection
            }
        }
    }
}

extension Volume {
    func canvasSize(_ size: CGSize, at index: Int) -> CGSize {
        CGSize(width: size.width, height: max(40, size.height - (pages[index].chapter == nil ? 0 : 92)))
    }

    @MainActor
    @discardableResult
    mutating func paginate(to size: CGSize, startingAt start: Int = 0, value: NSAttributedString? = nil) -> Bool {
        guard size.width > 1, size.height > 1, pages.indices.contains(start) else { return true }
        var revised = pages
        var selected = position
        var index = start
        while index < revised.count {
            var page = revised[index]
            let original = index == start ? value ?? PageDocument.contents(of: page) : PageDocument.contents(of: page)
            let text = PageDocument.moveInlineImages(in: original, into: &page)
            let migrated = text.length != original.length
            revised[index] = page
            let canvas = CGSize(width: size.width, height: max(40, size.height - (page.chapter == nil ? 0 : 92)))
            let boundary = PageDocument.splitPoint(text, in: canvas, objects: page.objects ?? [])
            do {
                if boundary < text.length && (boundary > 0 || page.chapter != nil || !(page.objects ?? []).isEmpty) {
                    let head = text.attributedSubstring(from: NSRange(location: 0, length: boundary))
                    let tail = text.attributedSubstring(from: NSRange(location: boundary, length: text.length - boundary))
                    try PageDocument.set(&revised[index], to: head)
                    var continuation = Folio()
                    try PageDocument.set(&continuation, to: tail)
                    revised.insert(continuation, at: index + 1)
                    if selected > index { selected += 1 }
                } else if migrated || (index == start && value != nil) {
                    try PageDocument.set(&revised[index], to: text)
                }
            } catch {
                return false
            }
            index += 1
        }
        pages = revised
        position = selected
        return true
    }
}

struct PageEditor: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var phase
    @StateObject private var document = PageDocument()
    @State var book: Volume
    let pageSize: CGSize
    let save: (Volume) -> Bool
    @State private var photo: PhotosPickerItem?
    @State private var panel: Panel?
    @State private var problem = false
    @State private var focusNext = false
    @State private var refresh = UUID()
    @State private var textOffset: CGFloat = 0
    @State private var arrangeAfterDrawing = false
    @State private var styleName = "Cuerpo"

    private enum Panel: String, Identifiable {
        case format, drawing, layout
        var id: String { rawValue }
    }

    private var page: Folio { book.pages[book.position] }
    private var canvas: CGSize { book.canvasSize(pageSize, at: book.position) }

    var body: some View {
        VStack(spacing: 12) {
            HStack(spacing: 10) {
                RoundControl(icon: "chevron.left", label: "Volver a leer", action: finish)
                VStack(alignment: .leading, spacing: 3) {
                    Text(book.title).font(.system(.headline, design: .serif)).lineLimit(1)
                    Text("Página \(book.position + 1)").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                RoundControl(icon: "arrow.uturn.backward", label: "Deshacer") {
                    document.view?.undoManager?.undo()
                }
                RoundControl(icon: "checkmark", label: "Listo", action: finish)
            }

            ZStack(alignment: .topLeading) {
                WritingSurface(page: page, document: document, canvas: canvas,
                               autofocus: focusNext, changed: handleTyping,
                               didScroll: { textOffset = $0 })
                    .id("\(page.id)-\(refresh)")
                ForEach(page.objects ?? []) { object in
                    let rect = object.rect(in: canvas)
                    ObjectView(object: object).frame(width: rect.width, height: rect.height)
                        .position(x: rect.midX, y: rect.midY - textOffset)
                        .allowsHitTesting(false)
                        .accessibilityHidden(true)
                }
            }
            .frame(width: canvas.width)
            .clipped()
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            toolbar

            HStack {
                Button { changePage(-1) } label: { Label("Anterior", systemImage: "arrow.left") }
                    .disabled(book.position == 0)
                Spacer()
                if !(page.objects ?? []).isEmpty {
                    RoundControl(icon: "arrow.up.left.and.arrow.down.right", label: "Colocar objetos") { arrange() }
                }
                Spacer()
                Button { changePage(1) } label: {
                    Label(book.position + 1 == book.pages.count ? "Nueva página" : "Siguiente",
                          systemImage: book.position + 1 == book.pages.count ? "plus" : "arrow.right")
                }
            }
            .buttonStyle(GlassButton())
        }
        .padding(.horizontal, 17)
        .padding(.top, 5)
        .padding(.bottom, 7)
        .background(ink.ignoresSafeArea())
        .foregroundStyle(paper)
        .interactiveDismissDisabled()
        .onChange(of: phase) { _, phase in if phase == .background { _ = store() } }
        .task(id: photo) {
            guard let photo else { return }
            let destination = page.id
            let bytes = try? await photo.loadTransferable(type: Data.self)
            guard !Task.isCancelled else { return }
            defer { self.photo = nil }
            guard page.id == destination else { return }
            if let bytes, let data = photoData(bytes, maximum: 1400), let image = UIImage(data: data) {
                add(PageObject(kind: .photo, image: data, aspect: image.size.width / image.size.height))
            } else { problem = true }
        }
        .sheet(item: $panel, onDismiss: {
            if arrangeAfterDrawing {
                arrangeAfterDrawing = false
                panel = .layout
            }
        }) { panel in
            switch panel {
            case .format:
                formatPanel
                    .presentationDetents([.height(290), .medium])
            case .drawing:
                SketchSheet { image in
                    guard let data = image.pngData() else { return }
                    arrangeAfterDrawing = add(PageObject(kind: .drawing, image: data, aspect: image.size.width / image.size.height),
                                              openLayout: false)
                }
            case .layout:
                PlacementSheet(page: page, size: canvas) { objects in
                    var updated = book
                    updated.pages[updated.position].objects = objects
                    guard updated.paginate(to: pageSize, startingAt: updated.position), save(updated) else {
                        problem = true
                        return false
                    }
                    book = updated
                    focusNext = false
                    refresh = UUID()
                    textOffset = 0
                    return true
                }
            }
        }
        .alert("Relevant", isPresented: $problem) {
            Button("Entendido", role: .cancel) {}
        } message: {
            Text("No se pudo completar el cambio. Vuelve a intentarlo.")
        }
    }

    private var toolbar: some View {
        HStack(spacing: 0) {
            Button { panel = .format } label: {
                Text("Aa").font(.headline).frame(maxWidth: .infinity, minHeight: 45)
            }
            .accessibilityLabel("Formato")
            icon("list.bullet", "Viñeta") { document.insert("• ") }
            PhotosPicker(selection: $photo, matching: .images) {
                Image(systemName: "photo").frame(maxWidth: .infinity, minHeight: 45)
            }
            .accessibilityLabel("Insertar foto")
            icon("pencil.tip", "Dibujo") { panel = .drawing }
            icon("tablecells", "Insertar tabla") {
                add(PageObject(kind: .table, cells: [["", ""], ["", ""]], width: 0.64, aspect: 1.8))
            }
        }
        .font(.system(size: 19))
        .buttonStyle(.plain)
        .modifier(GlassSurface(shape: Capsule(), interactive: true))
    }

    private var formatPanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("Formato").font(.title2.weight(.semibold))
                Spacer()
                RoundControl(icon: "xmark", label: "Cerrar formato") { panel = nil }
            }
            ScrollView(.horizontal) {
                HStack(spacing: 6) {
                    format("Título", font: PageDocument.typeface(30, weight: .bold))
                    format("Encabezado", font: PageDocument.typeface(25, weight: .bold))
                    format("Subtítulo", font: PageDocument.typeface(21, weight: .bold))
                    format("Cuerpo", font: PageDocument.font)
                    format("Monoespaciado", font: .monospacedSystemFont(ofSize: 18, weight: .regular))
                }
                .padding(5)
            }
            .scrollIndicators(.hidden)
            .modifier(GlassSurface(shape: Capsule()))
            HStack {
                icon("bold", "Negrita") { document.fontTrait(.traitBold) }
                icon("italic", "Cursiva") { document.fontTrait(.traitItalic) }
                icon("underline", "Subrayado") { document.toggle(.underlineStyle, value: 1) }
                icon("strikethrough", "Tachado") { document.toggle(.strikethroughStyle, value: 1) }
                icon("highlighter", "Resaltar") {
                    document.toggle(.backgroundColor, value: UIColor.systemGray.withAlphaComponent(0.35))
                }
            }
            .modifier(GlassSurface(shape: Capsule()))
            HStack {
                icon("list.bullet", "Viñeta") { document.insert("• "); panel = nil }
                icon("list.number", "Lista numerada") { document.insert("1. "); panel = nil }
                icon("text.alignleft", "Alinear a la izquierda") { document.align(.left) }
                icon("text.aligncenter", "Centrar texto") { document.align(.center) }
                icon("text.alignright", "Alinear a la derecha") { document.align(.right) }
            }
            .modifier(GlassSurface(shape: Capsule()))
        }
        .buttonStyle(.plain)
        .foregroundStyle(paper)
        .padding(18)
    }

    private func format(_ name: String, font: UIFont) -> some View {
        Button {
            styleName = name
            document.applyTypeface(font)
        } label: {
            Text(name).font(.custom(font.fontName, size: font.pointSize)).lineLimit(1).padding(.horizontal, 12).frame(height: 38)
                .background(paper.opacity(styleName == name ? 0.16 : 0), in: Capsule())
        }
    }

    private func icon(_ symbol: String, _ title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol).frame(maxWidth: .infinity, minHeight: 44)
        }
        .accessibilityLabel(title)
    }

    @discardableResult
    private func add(_ object: PageObject, openLayout: Bool = true) -> Bool {
        focusNext = false
        document.view?.resignFirstResponder()
        var updated = book
        updated.pages[updated.position].objects = (page.objects ?? []) + [object]
        guard store(updated) else { return false }
        if openLayout { panel = .layout }
        return true
    }

    private func arrange() {
        document.view?.resignFirstResponder()
        if store() { panel = .layout }
    }

    private func handleTyping(_ editor: UITextView) {
        guard editor.markedTextRange == nil, editor.selectedRange.location == editor.textStorage.length,
              case nil = panel else { return }
        let split = PageDocument.splitPoint(editor.attributedText, in: canvas, objects: page.objects ?? [])
        // Keep paragraph-ending whitespace on the current page until there is text to continue.
        let tail = (editor.text as NSString).substring(from: split)
        guard split < editor.textStorage.length,
              !tail.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        focusNext = true
        _ = store(offset: 1)
    }

    private func store(_ draft: Volume? = nil, offset: Int = 0) -> Bool {
        var updated = draft ?? book
        let current = updated.position
        let liveText = document.view?.attributedText
        guard updated.paginate(to: pageSize, startingAt: current, value: liveText) else {
            problem = true
            return false
        }
        if current + offset == updated.pages.count { updated.pages.append(Folio()) }
        updated.position = current + offset
        guard save(updated) else { problem = true; return false }
        if offset != 0 { textOffset = 0 }
        if offset == 0, let liveText, liveText.string != updated.pages[current].text {
            document.view?.attributedText = PageDocument.contents(of: updated.pages[current])
        }
        book = updated
        return true
    }

    private func changePage(_ offset: Int) {
        guard book.position + offset >= 0 else { return }
        focusNext = document.view?.isFirstResponder ?? false
        _ = store(offset: offset)
    }

    private func finish() {
        if store() { dismiss() }
    }
}

struct WritingSurface: UIViewRepresentable {
    var page: Folio
    let document: PageDocument
    var canvas: CGSize
    var autofocus: Bool
    var changed: (UITextView) -> Void
    var didScroll: (CGFloat) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(changed: changed, didScroll: didScroll) }

    func makeUIView(context: Context) -> UITextView {
        let view = PageDocument.textView()
        view.keyboardDismissMode = .interactive
        view.isScrollEnabled = false
        view.attributedText = PageDocument.contents(of: page)
        view.typingAttributes = PageDocument.attributes
        view.accessibilityLabel = "Texto de la página"
        view.delegate = context.coordinator
        document.view = view
        if autofocus {
            DispatchQueue.main.async { [weak view] in
                guard let view, view.window != nil else { return }
                view.selectedRange = NSRange(location: view.textStorage.length, length: 0)
                view.becomeFirstResponder()
            }
        }
        return view
    }

    func updateUIView(_ view: UITextView, context: Context) {
        context.coordinator.changed = changed
        context.coordinator.didScroll = didScroll
        view.textContainer.exclusionPaths = PageDocument.paths(page.objects ?? [], in: canvas)
    }

    final class Coordinator: NSObject, UITextViewDelegate {
        var changed: (UITextView) -> Void
        var didScroll: (CGFloat) -> Void

        init(changed: @escaping (UITextView) -> Void, didScroll: @escaping (CGFloat) -> Void) {
            self.changed = changed
            self.didScroll = didScroll
        }

        func scrollViewDidScroll(_ scrollView: UIScrollView) {
            let offset = scrollView.contentOffset.y
            DispatchQueue.main.async { [weak scrollView] in
                guard scrollView?.window != nil else { return }
                self.didScroll(offset)
            }
        }

        func textViewDidBeginEditing(_ textView: UITextView) {
            textView.isScrollEnabled = true
        }

        func textViewDidEndEditing(_ textView: UITextView) {
            textView.setContentOffset(.zero, animated: false)
            textView.isScrollEnabled = false
        }

        func textViewDidChange(_ textView: UITextView) {
            let range = NSRange(location: 0, length: textView.textStorage.length)
            textView.textStorage.addAttribute(.foregroundColor, value: UIColor.label, range: range)
            var attributes = textView.typingAttributes
            attributes[.foregroundColor] = UIColor.label
            textView.typingAttributes = attributes
            changed(textView)
        }
    }
}

struct SketchSheet: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var scheme
    @State private var sketch = PKDrawing()
    let insert: (UIImage) -> Void

    var body: some View {
        VStack {
            HStack {
                Button("Cancelar") { dismiss() }
                Spacer()
                Text("Dibujo").font(.system(.title3, design: .serif))
                Spacer()
                Button("Insertar") {
                    let bounds = sketch.bounds.insetBy(dx: -8, dy: -8)
                    insert(sketch.image(from: bounds, scale: 1))
                    dismiss()
                }
                .disabled(sketch.strokes.isEmpty)
            }
            .buttonStyle(GlassButton())
            .padding()
            SketchCanvas(sketch: $sketch, dark: scheme == .dark)
        }
        .foregroundStyle(paper)
        .background(ink.ignoresSafeArea())
    }
}

struct SketchCanvas: UIViewRepresentable {
    @Binding var sketch: PKDrawing
    var dark: Bool

    func makeCoordinator() -> Coordinator { Coordinator(sketch: $sketch) }

    func makeUIView(context: Context) -> PKCanvasView {
        let canvas = PKCanvasView()
        canvas.backgroundColor = dark ? .black : .white
        canvas.drawingPolicy = .anyInput
        canvas.tool = PKInkingTool(.pen, color: dark ? .white : .black, width: 4)
        canvas.delegate = context.coordinator
        canvas.isScrollEnabled = false
        canvas.accessibilityLabel = "Lienzo de dibujo"
        return canvas
    }

    func updateUIView(_ canvas: PKCanvasView, context: Context) {}

    final class Coordinator: NSObject, PKCanvasViewDelegate {
        var sketch: Binding<PKDrawing>

        init(sketch: Binding<PKDrawing>) { self.sketch = sketch }

        func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
            sketch.wrappedValue = canvasView.drawing
        }
    }
}

struct ObjectView: View {
    let object: PageObject
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        GeometryReader { geometry in
            if let cells = object.cells, object.kind == .table {
                let columns = max(cells.first?.count ?? 1, 1)
                let cellWidth = geometry.size.width / CGFloat(columns)
                let cellHeight = geometry.size.height / CGFloat(max(1, cells.count))
                VStack(spacing: 0) {
                    ForEach(cells.indices, id: \.self) { row in
                        HStack(spacing: 0) {
                            ForEach(cells[row].indices, id: \.self) { column in
                                Text(cells[row][column])
                                    .font(.system(size: 12, weight: row == 0 ? .semibold : .regular))
                                    .padding(3).lineLimit(3).minimumScaleFactor(0.72)
                                    .frame(width: cellWidth, height: cellHeight)
                                    .background(row == 0 ? paper.opacity(0.08) : ink)
                                    .overlay { Rectangle().strokeBorder(paper.opacity(0.24), lineWidth: 0.5) }
                            }
                        }
                    }
                }
                .clipped()
                .accessibilityLabel("Tabla")
            } else if let data = object.image, let image = UIImage(data: data) {
                if object.kind == .drawing {
                    Image(uiImage: image).renderingMode(.template).resizable().scaledToFit()
                        .foregroundStyle(scheme == .dark ? .white : .black)
                        .accessibilityLabel("Dibujo")
                } else {
                    Image(uiImage: image).resizable().scaledToFit().accessibilityLabel("Foto")
                }
            }
        }
    }
}

struct PlacementSheet: View {
    @Environment(\.dismiss) private var dismiss
    @State private var objects: [PageObject]
    @State private var selected: UUID?
    @State private var dragOrigin: CGPoint?
    @State private var editingTable = false
    let page: Folio
    let size: CGSize
    let save: ([PageObject]) -> Bool

    init(page: Folio, size: CGSize, save: @escaping ([PageObject]) -> Bool) {
        self.page = page
        self.size = size
        self.save = save
        _objects = State(initialValue: page.objects ?? [])
        _selected = State(initialValue: page.objects?.last?.id)
    }

    private var index: Int? { objects.firstIndex { $0.id == selected } }

    var body: some View {
        VStack(spacing: 12) {
            HStack {
                RoundControl(icon: "xmark", label: "Cancelar") { dismiss() }
                Spacer()
                Text("Composición").font(.system(.title3, design: .serif))
                Spacer()
                RoundControl(icon: "checkmark", label: "Aplicar composición") {
                    if save(objects) { dismiss() }
                }
            }
            GeometryReader { geometry in
                let scale = max(0.05, min(geometry.size.width / max(size.width, 1),
                                          geometry.size.height / max(size.height, 1)))
                ZStack(alignment: .topLeading) {
                    let draft = Folio(text: page.text, richText: page.richText, objects: objects)
                    PageText(page: draft, size: size).allowsHitTesting(false)
                    ForEach(objects) { object in
                        let rect = object.rect(in: size)
                        ObjectView(object: object)
                            .frame(width: rect.width, height: rect.height)
                            .overlay {
                                if object.id == selected {
                                    Rectangle().strokeBorder(paper.opacity(0.7),
                                                             style: StrokeStyle(lineWidth: 1, dash: [4, 3]))
                                }
                            }
                            .contentShape(Rectangle())
                            .onTapGesture { selected = object.id }
                            .gesture(DragGesture(minimumDistance: 4, coordinateSpace: .named("placement")).onChanged { drag in
                                guard let i = objects.firstIndex(where: { $0.id == object.id }) else { return }
                                selected = object.id
                                if dragOrigin == nil { dragOrigin = CGPoint(x: rect.midX, y: rect.midY) }
                                guard let origin = dragOrigin else { return }
                                objects[i].x = min(1, max(0, (origin.x + drag.translation.width) / size.width))
                                objects[i].y = min(1, max(0, (origin.y + drag.translation.height) / size.height))
                            }.onEnded { _ in dragOrigin = nil })
                            .position(x: rect.midX, y: rect.midY)
                    }
                }
                .frame(width: size.width, height: size.height)
                .coordinateSpace(name: "placement")
                .background(ink)
                .clipped()
                .overlay { Rectangle().strokeBorder(paper.opacity(0.16)).allowsHitTesting(false) }
                .scaleEffect(scale)
                .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
            }
            if let index {
                HStack(spacing: 15) {
                    Slider(value: $objects[index].width, in: 0.16...0.96) { Text("Tamaño") }
                    if objects[index].kind == .table {
                        RoundControl(icon: "tablecells", label: "Editar celdas") { editingTable = true }
                    }
                    RoundControl(icon: "trash", label: "Quitar objeto de la página") {
                        objects.remove(at: index)
                        selected = objects.last?.id
                    }
                }
            }
        }
        .padding(18)
        .foregroundStyle(paper)
        .background(ink.ignoresSafeArea())
        .sheet(isPresented: $editingTable) {
            if let index, let cells = objects[index].cells {
                let id = objects[index].id
                TableSheet(cells: cells) { newCells in
                    guard let match = objects.firstIndex(where: { $0.id == id }) else { return }
                    objects[match].cells = newCells
                    objects[match].aspect = Double(newCells[0].count) * 1.8 / Double(newCells.count)
                }
            }
        }
    }
}

struct TableSheet: View {
    @Environment(\.dismiss) private var dismiss
    @State var cells: [[String]]
    let save: ([[String]]) -> Void

    var body: some View {
        VStack(spacing: 15) {
            HStack {
                RoundControl(icon: "xmark", label: "Cancelar") { dismiss() }
                Spacer()
                Text("Tabla").font(.system(.title3, design: .serif))
                Spacer()
                RoundControl(icon: "checkmark", label: "Guardar celdas") { save(cells); dismiss() }
            }
            ScrollView([.horizontal, .vertical]) {
                VStack(alignment: .leading, spacing: 1) {
                    ForEach(cells.indices, id: \.self) { row in
                        HStack(spacing: 1) {
                            ForEach(cells[row].indices, id: \.self) { column in
                                TextField("Celda", text: $cells[row][column], axis: .vertical)
                                    .accessibilityLabel("Fila \(row + 1), columna \(column + 1)")
                                    .padding(9)
                                    .frame(width: 115, alignment: .leading)
                                    .background(paper.opacity(0.08))
                            }
                        }
                    }
                }
            }
            HStack {
                Button("Añadir fila") { cells.append(Array(repeating: "", count: cells[0].count)) }
                    .disabled(cells.count >= 8)
                Button("Añadir columna") {
                    for index in cells.indices { cells[index].append("") }
                }
                .disabled(cells[0].count >= 6)
            }
            .buttonStyle(GlassButton())
        }
        .padding(18)
        .foregroundStyle(paper)
        .background(ink.ignoresSafeArea())
    }
}
