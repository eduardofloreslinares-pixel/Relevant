import SwiftUI
import PhotosUI
import PencilKit
import UIKit

@MainActor
final class PageDocument: ObservableObject {
    static let font = UIFont.systemFont(ofSize: 19)
    static let attributes: [NSAttributedString.Key: Any] = [
        .font: font, .foregroundColor: UIColor(paper)
    ]
    weak var view: UITextView?

    static func contents(of page: Folio) -> NSAttributedString {
        if let data = page.richText,
           let rich = try? NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.rtfd],
                                              documentAttributes: nil) {
            return rich
        }
        return NSAttributedString(string: page.text, attributes: attributes)
    }

    func commit(to page: inout Folio) throws {
        guard let value = view?.attributedText else { return }
        page.richText = value.length == 0 ? nil : try value.data(
            from: NSRange(location: 0, length: value.length),
            documentAttributes: [.documentType: NSAttributedString.DocumentType.rtfd]
        )
        page.text = value.string
    }

    func style(_ key: NSAttributedString.Key, value: Any?) {
        guard let view else { return }
        let selection = view.selectedRange
        if selection.length == 0 {
            var typing = view.typingAttributes
            typing[key] = value
            view.typingAttributes = typing
            view.becomeFirstResponder()
            return
        }
        remember(view)
        if let value { view.textStorage.addAttribute(key, value: value, range: selection) }
        else { view.textStorage.removeAttribute(key, range: selection) }
        view.selectedRange = selection
        view.becomeFirstResponder()
    }

    func current(_ key: NSAttributedString.Key) -> Any? {
        guard let view else { return nil }
        let range = view.selectedRange
        if range.length > 0 { return view.textStorage.attribute(key, at: range.location, effectiveRange: nil) }
        return view.typingAttributes[key]
    }

    func fontTrait(_ trait: UIFontDescriptor.SymbolicTraits) {
        let font = current(.font) as? UIFont ?? Self.font
        let traits = font.fontDescriptor.symbolicTraits.symmetricDifference(trait)
        if let descriptor = font.fontDescriptor.withSymbolicTraits(traits) {
            style(.font, value: UIFont(descriptor: descriptor, size: font.pointSize))
        }
    }

    func toggle(_ key: NSAttributedString.Key, value: Any) {
        style(key, value: current(key) == nil ? value : nil)
    }

    func insert(_ string: String) {
        insert(NSAttributedString(string: string, attributes: view?.typingAttributes ?? Self.attributes))
    }

    func insertPhoto(_ image: UIImage) {
        guard image.size.width > 0, image.size.height > 0 else { return }
        let scale = min(225 / image.size.width, 240 / image.size.height, 1)
        let size = CGSize(width: max(1, image.size.width * scale), height: max(1, image.size.height * scale))
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let thumbnail = UIGraphicsImageRenderer(size: size, format: format).image { _ in
            image.draw(in: CGRect(origin: .zero, size: size))
        }
        let attachment = NSTextAttachment()
        attachment.image = thumbnail
        attachment.bounds = CGRect(origin: .zero, size: size)
        let result = NSMutableAttributedString(string: "\n", attributes: Self.attributes)
        result.append(NSAttributedString(attachment: attachment))
        result.append(NSAttributedString(string: "\n", attributes: Self.attributes))
        insert(result)
    }

    func insertLink(_ url: URL) {
        if let view, view.selectedRange.length > 0 {
            style(.link, value: url)
        } else {
            var attributes = Self.attributes
            attributes[.link] = url
            insert(NSAttributedString(string: url.absoluteString, attributes: attributes))
            view?.typingAttributes = Self.attributes
        }
    }

    private func insert(_ text: NSAttributedString) {
        guard let view else { return }
        let selection = view.selectedRange
        remember(view)
        view.textStorage.replaceCharacters(in: selection, with: text)
        view.selectedRange = NSRange(location: selection.location + text.length, length: 0)
        view.becomeFirstResponder()
    }

    private func remember(_ view: UITextView) {
        let snapshot = NSAttributedString(attributedString: view.attributedText)
        let selection = view.selectedRange
        view.undoManager?.registerUndo(withTarget: self) { document in
            MainActor.assumeIsolated {
                guard let editor = document.view, editor === view else { return }
                document.remember(editor)
                editor.attributedText = snapshot
                editor.selectedRange = selection
            }
        }
    }
}

struct PageEditor: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var phase
    @StateObject private var document = PageDocument()
    @State var book: Volume
    let save: (Volume) -> Bool
    @State private var photo: PhotosPickerItem?
    @State private var drawing = false
    @State private var problem: String?
    @State private var linking = false
    @State private var link = ""

    private var page: Folio { book.pages[book.position] }

    var body: some View {
        VStack(spacing: 9) {
            HStack {
                RoundControl(icon: "chevron.left", label: "Volver a leer") { finish() }
                VStack(alignment: .leading, spacing: 3) {
                    Text(book.title).font(.system(.headline, design: .serif)).lineLimit(1)
                    Text("Página \(book.position + 1)").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                RoundControl(icon: "arrow.uturn.backward", label: "Deshacer") { document.view?.undoManager?.undo() }
                Button("Listo", action: finish)
                    .buttonStyle(.borderedProminent)
            }
            .padding(.horizontal, 18)

            WritingSurface(page: page, document: document)
                .id(page.id)
                .padding(.horizontal, 25)

            ScrollView(.horizontal) {
                HStack(spacing: 1) {
                    Menu {
                        Button("Título") { document.style(.font, value: UIFont.systemFont(ofSize: 29, weight: .bold)) }
                        Button("Subtítulo") { document.style(.font, value: UIFont.systemFont(ofSize: 23, weight: .semibold)) }
                        Button("Cuerpo") { document.style(.font, value: PageDocument.font) }
                        Divider()
                        Button("Negrita") { document.fontTrait(.traitBold) }
                        Button("Cursiva") { document.fontTrait(.traitItalic) }
                        Button("Subrayado") { document.toggle(.underlineStyle, value: NSUnderlineStyle.single.rawValue) }
                        Button("Tachado") { document.toggle(.strikethroughStyle, value: NSUnderlineStyle.single.rawValue) }
                        Button("Resaltar") { document.toggle(.backgroundColor, value: UIColor.systemOrange.withAlphaComponent(0.36)) }
                    } label: {
                        Text("Aa").font(.system(size: 18, weight: .medium)).frame(width: 45, height: 44)
                    }
                    .accessibilityLabel("Formato")
                    tool("checklist", "Casilla de lista") {
                        if let view = document.view, view.selectedRange.length > 0,
                           let range = Range(view.selectedRange, in: view.text),
                           view.text[range] == "☐" || view.text[range] == "☑" {
                            document.insert(view.text[range] == "☐" ? "☑" : "☐")
                        } else {
                            document.insert("☐ ")
                        }
                    }
                    tool("list.bullet", "Viñeta") { document.insert("• ") }
                    PhotosPicker(selection: $photo, matching: .images) {
                        Image(systemName: "photo").frame(width: 45, height: 44)
                    }
                    .accessibilityLabel("Insertar foto")
                    tool("pencil.tip", "Insertar dibujo") { drawing = true }
                    tool("link", "Insertar enlace") {
                        link = ""
                        linking = true
                    }
                }
                .padding(.horizontal, 6)
            }
            .scrollIndicators(.hidden)
            .background(.thinMaterial, in: Capsule())
            .padding(.horizontal, 18)

            HStack {
                Button { changePage(-1) } label: {
                    Label("Anterior", systemImage: "arrow.left")
                }
                .disabled(book.position == 0)
                Spacer()
                Button { changePage(1) } label: {
                    Label(book.position + 1 == book.pages.count ? "Nueva página" : "Siguiente",
                          systemImage: book.position + 1 == book.pages.count ? "plus" : "arrow.right")
                }
            }
            .buttonStyle(.bordered)
            .padding(.horizontal, 18)
            .padding(.bottom, 6)
        }
        .padding(.top, 5)
        .background(ink.ignoresSafeArea())
        .foregroundStyle(paper)
        .interactiveDismissDisabled()
        .onChange(of: phase) { _, phase in
            if phase == .background { _ = store() }
        }
        .sheet(isPresented: $drawing) {
            SketchSheet { document.insertPhoto($0) }
        }
        .task(id: photo) {
            guard let photo else { return }
            let destination = page.id
            let bytes = try? await photo.loadTransferable(type: Data.self)
            guard !Task.isCancelled else { return }
            defer { self.photo = nil }
            guard page.id == destination else { return }
            if let bytes, let photo = photoData(bytes, maximum: 850), let image = UIImage(data: photo) {
                document.insertPhoto(image)
            } else {
                problem = "No se pudo cargar la foto."
            }
        }
        .alert("Añadir enlace", isPresented: $linking) {
            TextField("https://", text: $link).keyboardType(.URL).textInputAutocapitalization(.never)
            Button("Cancelar", role: .cancel) {}
            Button("Insertar") {
                guard let url = URL(string: link.trimmingCharacters(in: .whitespacesAndNewlines)),
                      let scheme = url.scheme?.lowercased(), ["https", "http"].contains(scheme),
                      url.host != nil else {
                    problem = "Introduce una dirección web válida."
                    return
                }
                document.insertLink(url)
            }
        }
        .alert("Relevant", isPresented: Binding(
            get: { problem != nil }, set: { if !$0 { problem = nil } }
        )) {
            Button("Entendido", role: .cancel) {}
        } message: {
            Text(problem ?? "")
        }
    }

    private func tool(_ icon: String, _ label: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon).frame(width: 45, height: 44)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }

    private func store(offset: Int = 0) -> Bool {
        var updated = book
        do {
            try document.commit(to: &updated.pages[updated.position])
        } catch {
            problem = "No se pudo guardar el formato de esta página."
            return false
        }
        if updated.position + offset == updated.pages.count { updated.pages.append(Folio()) }
        updated.position += offset
        guard save(updated) else {
            problem = "No se guardaron los cambios. Vuelve a intentarlo."
            return false
        }
        book = updated
        return true
    }

    private func changePage(_ offset: Int) {
        guard book.position + offset >= 0 else { return }
        _ = store(offset: offset)
    }

    private func finish() {
        if store() { dismiss() }
    }
}

struct WritingSurface: UIViewRepresentable {
    var page: Folio
    let document: PageDocument

    func makeUIView(context: Context) -> UITextView {
        let view = UITextView()
        view.backgroundColor = .clear
        view.textContainerInset = UIEdgeInsets(top: 15, left: 0, bottom: 15, right: 0)
        view.textContainer.lineFragmentPadding = 0
        view.font = PageDocument.font
        view.textColor = UIColor(paper)
        view.tintColor = UIColor(copper)
        view.keyboardAppearance = .dark
        view.keyboardDismissMode = .interactive
        view.attributedText = PageDocument.contents(of: page)
        view.typingAttributes = PageDocument.attributes
        view.allowsEditingTextAttributes = true
        view.accessibilityLabel = "Texto de la página"
        document.view = view
        return view
    }

    func updateUIView(_ view: UITextView, context: Context) {}
}


struct SketchSheet: View {
    @Environment(\.dismiss) private var dismiss
    @State private var sketch = PKDrawing()
    let insert: (UIImage) -> Void

    var body: some View {
        VStack {
            HStack {
                Button("Cancelar") { dismiss() }
                Spacer()
                Text("Dibujo").font(.system(.title3, design: .serif))
                Spacer()
                Button("Insertar") {
                    let bounds = sketch.bounds.insetBy(dx: -8, dy: -8)
                    insert(sketch.image(from: bounds, scale: 1))
                    dismiss()
                }
                .disabled(sketch.strokes.isEmpty)
            }
            .padding()
            SketchCanvas(sketch: $sketch)
        }
        .foregroundStyle(paper)
        .background(ink.ignoresSafeArea())
    }
}

struct SketchCanvas: UIViewRepresentable {
    @Binding var sketch: PKDrawing

    func makeCoordinator() -> Coordinator { Coordinator(sketch: $sketch) }

    func makeUIView(context: Context) -> PKCanvasView {
        let canvas = PKCanvasView()
        canvas.backgroundColor = UIColor(ink)
        canvas.drawingPolicy = .anyInput
        canvas.tool = PKInkingTool(.pen, color: UIColor(copper), width: 4)
        canvas.delegate = context.coordinator
        canvas.isScrollEnabled = false
        canvas.accessibilityLabel = "Lienzo de dibujo"
        return canvas
    }

    func updateUIView(_ canvas: PKCanvasView, context: Context) {}

    final class Coordinator: NSObject, PKCanvasViewDelegate {
        var sketch: Binding<PKDrawing>

        init(sketch: Binding<PKDrawing>) { self.sketch = sketch }

        func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
            sketch.wrappedValue = canvasView.drawing
        }
    }
}
