import SwiftUI
import PhotosUI
import UIKit

let ink = Color(uiColor: UIColor { $0.userInterfaceStyle == .dark ? .black : .white })
let paper = Color(uiColor: .label)
let copper = Color(uiColor: .label)

struct GlassSurface<S: Shape>: ViewModifier {
    let shape: S
    var interactive = false

    @ViewBuilder func body(content: Content) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26, *) {
            content.glassEffect(interactive ? .regular.interactive() : .regular, in: shape)
        } else {
            content.background(.regularMaterial, in: shape)
        }
        #else
        content.background(.regularMaterial, in: shape)
        #endif
    }
}

struct GlassButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding(.horizontal, 15)
            .frame(minHeight: 42)
            .background {
                Capsule().fill(.clear)
                    .modifier(GlassSurface(shape: Capsule()))
                    .allowsHitTesting(false)
            }
            .contentShape(Capsule())
            .opacity(configuration.isPressed ? 0.65 : 1)
    }
}

@main
struct RelevantApp: App {
    @StateObject private var archive = Archive()

    var body: some Scene {
        WindowGroup {
            LibraryView()
                .environmentObject(archive)
                .tint(copper)
                .alert("Relevant", isPresented: Binding(
                    get: { archive.problem != nil },
                    set: { if !$0 { archive.problem = nil } }
                )) {
                    Button("Entendido", role: .cancel) {}
                } message: {
                    Text(archive.problem ?? "")
                }
        }
    }
}

struct RoundControl: View {
    var icon: String
    var label: String
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 17, weight: .medium))
                .frame(width: 46, height: 46)
                .background {
                    Circle().fill(.clear)
                        .modifier(GlassSurface(shape: Circle()))
                        .allowsHitTesting(false)
                }
                .contentShape(Circle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }
}

struct LibraryView: View {
    @EnvironmentObject private var archive: Archive
    @State private var reading: Volume?
    @State private var settlingClose = false
    @State private var openingBook = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var coverFrames: [UUID: CGRect] = [:]
    @State private var closeFlight: BookCloseFlight?
    @State private var closeProgress: CGFloat = 0
    private enum BookForm: Identifiable {
        case create, edit(Volume)

        var id: String {
            switch self {
            case .create: "new"
            case let .edit(book): book.id.uuidString
            }
        }
    }

    @State private var form: BookForm?
    @State private var pendingDeletion: Volume?
    @State private var searching = false
    @State private var query = ""
    @FocusState private var searchFocus: Bool

    private var results: [Volume] {
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !term.isEmpty else { return archive.books }
        return archive.books.filter { book in
            book.title.localizedStandardContains(term) || book.pages.contains {
                $0.text.localizedStandardContains(term) || ($0.chapter?.localizedStandardContains(term) ?? false)
            }
        }
    }

    var body: some View {
        Group {
            ScrollView {
                VStack(alignment: .leading, spacing: 23) {
                    HStack(spacing: 10) {
                        Text("Biblioteca")
                            .font(.system(size: 39, weight: .semibold, design: .serif))
                            .accessibilityAddTraits(.isHeader)
                        Spacer()
                        RoundControl(icon: searching ? "xmark" : "magnifyingglass", label: searching ? "Cerrar búsqueda" : "Buscar") {
                            searching.toggle()
                            searchFocus = searching
                            if !searching { query = "" }
                        }
                        RoundControl(icon: "plus", label: "Crear libro") { form = .create }
                    }
                    if searching {
                        TextField("Buscar en libros y páginas", text: $query)
                            .padding(13)
                            .modifier(GlassSurface(shape: RoundedRectangle(cornerRadius: 12)))
                            .focused($searchFocus)
                    }
                    Rectangle().fill(copper.opacity(0.26)).frame(height: 1)
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 140, maximum: 210), spacing: 22, alignment: .bottom)], spacing: 27) {
                        ForEach(results) { book in
                            Button {
                                searchFocus = false
                                openingBook = !reduceMotion
                                reading = book
                            } label: {
                                Hardcover(title: book.title, ratio: book.proportion, photo: book.cover)
                                    .onGeometryChange(for: CGRect.self) { $0.frame(in: .global) } action: { frame in
                                        if frame.width > 0, frame.height > 0, closeFlight == nil {
                                            coverFrames[book.id] = frame
                                        }
                                    }
                                    .opacity(closeFlight?.book.id == book.id ? 0 : 1)
                                    .accessibilityLabel(book.title)
                            }
                            .buttonStyle(.plain)
                            .contextMenu {
                                Button {
                                    form = .edit(book)
                                } label: {
                                    Label("Editar libro", systemImage: "pencil")
                                }
                                Button(role: .destructive) {
                                    pendingDeletion = book
                                } label: {
                                    Label("Eliminar libro", systemImage: "trash")
                                }
                            }
                        }
                    }
                    if results.isEmpty {
                        Text(searching ? "Sin coincidencias" : "Crea tu primer libro con +")
                            .foregroundStyle(.secondary)
                    }
                }
                .frame(maxWidth: 760)
                .padding(.horizontal, 25)
                .padding(.vertical, 18)
                .frame(maxWidth: .infinity)
            }
            .background(ink.ignoresSafeArea())
            .foregroundStyle(paper)
            .toolbar(.hidden, for: .navigationBar)
            .sheet(item: $form) { form in
                switch form {
                case .create: MakeBook()
                case let .edit(book): MakeBook(book: book)
                }
            }
            .alert("¿Eliminar libro?", isPresented: Binding(
                get: { pendingDeletion != nil },
                set: { if !$0 { pendingDeletion = nil } }
            ), presenting: pendingDeletion) { book in
                Button("Cancelar", role: .cancel) {}
                Button("Eliminar", role: .destructive) { archive.remove(book.id) }
            } message: { book in
                Text("Se eliminará «\(book.title)» con todas sus páginas.")
            }
        }
        .allowsHitTesting(reading == nil)
        .accessibilityHidden(reading != nil)
        .overlay {
            if let book = reading {
                ReaderView(book: book, initialPage: startPage(book)) { page, frame, gesture in
                    closeBook(book, page: page, frame: frame, gesture: gesture)
                }
                .opacity(closeFlight == nil && !openingBook ? 1 : 0.001)
            }
        }
        .overlay {
            if let flight = closeFlight {
                GeometryReader { geometry in
                    let origin = geometry.frame(in: .global).origin
                    BookCloseMorph(flight: flight, origin: origin, progress: closeProgress)
                }
                .allowsHitTesting(false)
                .accessibilityHidden(true)
            }
        }
    }

    private func closeBook(_ book: Volume, page: AnyView, frame: CGRect, gesture: ReaderCloseGesture) {
        guard !settlingClose else { return }
        guard !reduceMotion, let destination = coverFrames[book.id], destination.width > 1,
              destination.height > 1, frame.intersects(destination) else {
            switch gesture {
            case .open: openingBook = false
            case .button, .finish(true): reading = nil
            default: break
            }
            return
        }

        switch gesture {
        case .open:
            guard openingBook else { return }
            openingBook = false
            closeFlight = BookCloseFlight(book: book, page: page, start: frame, end: destination)
            closeProgress = 1
            settleClose(complete: false)
        case .drag(let progress):
            if closeFlight == nil {
                closeFlight = BookCloseFlight(book: book, page: page, start: frame, end: destination)
            }
            closeProgress = progress
        case .button:
            closeFlight = BookCloseFlight(book: book, page: page, start: frame, end: destination)
            settleClose(complete: true)
        case .finish(let complete):
            guard closeFlight != nil else { return }
            settleClose(complete: complete)
        }
    }

    private func settleClose(complete: Bool) {
        settlingClose = true
        Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(20))
            withAnimation(.smooth(duration: 0.34, extraBounce: 0), completionCriteria: .removed) {
                closeProgress = complete ? 1 : 0
            } completion: {
                if complete { reading = nil }
                closeFlight = nil
                closeProgress = 0
                settlingClose = false
            }
        }
    }

    private func startPage(_ book: Volume) -> Int {
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !term.isEmpty, !book.title.localizedStandardContains(term) else { return book.position }
        return book.pages.firstIndex {
            $0.text.localizedStandardContains(term) || ($0.chapter?.localizedStandardContains(term) ?? false)
        } ?? book.position
    }
}

private struct BookCloseFlight {
    let book: Volume
    let page: AnyView
    let start: CGRect
    let end: CGRect
}

private struct BookCloseMorph: View, Animatable {
    let flight: BookCloseFlight
    let origin: CGPoint
    var progress: CGFloat

    var animatableData: CGFloat {
        get { progress }
        set { progress = newValue }
    }

    var body: some View {
        let amount = min(max(progress, 0), 1)
        let start = flight.start
        let end = flight.end
        let width = start.width + (end.width - start.width) * amount
        let height = start.height + (end.height - start.height) * amount
        let paperScale = min(width / start.width, height / start.height)
        let coverScale = max(width / end.width, height / end.height)
        let blend = min(max((amount - 0.18) / 0.68, 0), 1)

        Color.clear
            .frame(width: width, height: height)
            .overlay {
                ZStack {
                    ink
                    flight.page
                        .frame(width: start.width, height: start.height)
                        .scaleEffect(paperScale)
                        .opacity(Double(1 - blend))
                    Hardcover(title: flight.book.title, ratio: flight.book.proportion,
                              photo: flight.book.cover, castsShadow: false)
                        .frame(width: end.width, height: end.height)
                        .scaleEffect(coverScale)
                        .opacity(Double(blend))
                }
                .frame(width: width, height: height)
            }
            .clipShape(RoundedRectangle(cornerRadius: 5 * amount))
            .shadow(color: Hardcover.shadowColor.opacity(Double(amount)),
                    radius: 8 * amount, x: 4 * amount, y: 7 * amount)
            .position(x: start.midX + (end.midX - start.midX) * amount - origin.x,
                      y: start.midY + (end.midY - start.midY) * amount - origin.y)
    }
}

struct Hardcover: View {
    static let shadowColor = Color.black.opacity(0.48)

    var title: String
    var ratio: Double
    var photo: Data?
    var castsShadow = true

    var body: some View {
        Color(white: 0.14)
            .aspectRatio(1 / ratio, contentMode: .fit)
            .overlay {
                GeometryReader { geometry in
                    if let photo, let image = UIImage(data: photo) {
                        Image(uiImage: image).resizable().scaledToFill()
                            .frame(width: geometry.size.width, height: geometry.size.height)
                    } else {
                        LinearGradient(colors: [Color(white: 0.29), Color(white: 0.08)],
                                       startPoint: .topLeading, endPoint: .bottomTrailing)
                    }
                }
                .clipped()
            }
            .overlay(alignment: .leading) {
                LinearGradient(stops: [
                    .init(color: .black.opacity(0.65), location: 0),
                    .init(color: .white.opacity(0.24), location: 0.22),
                    .init(color: .black.opacity(0.52), location: 0.70),
                    .init(color: .clear, location: 1)
                ], startPoint: .leading, endPoint: .trailing)
                .frame(width: 13)
            }
            .overlay {
                if photo == nil {
                    VStack(spacing: 13) {
                        Image(systemName: "sparkle").font(.system(size: 20, weight: .light))
                        Text(title.isEmpty ? "Sin título" : title)
                            .font(.system(size: 25, weight: .medium, design: .serif))
                            .multilineTextAlignment(.center)
                            .lineLimit(4)
                            .minimumScaleFactor(0.55)
                        Rectangle().fill(.white.opacity(0.60)).frame(width: 28, height: 1)
                    }
                    .foregroundStyle(.white)
                    .padding(.horizontal, 17)
                    .padding(.leading, 7)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .overlay {
                        RoundedRectangle(cornerRadius: 2).strokeBorder(.white.opacity(0.32))
                            .padding(.vertical, 13).padding(.leading, 19).padding(.trailing, 10)
                    }
                } else {
                    Text(title).foregroundStyle(.white).font(.system(.subheadline, design: .serif).weight(.semibold))
                        .lineLimit(2)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(10)
                        .padding(.leading, 6)
                        .background(.black.opacity(0.72))
                        .frame(maxHeight: .infinity, alignment: .bottom)
                }
            }
            .clipShape(.rect(topLeadingRadius: 3, bottomLeadingRadius: 3, bottomTrailingRadius: 6, topTrailingRadius: 6))
            .overlay { RoundedRectangle(cornerRadius: 5).strokeBorder(.white.opacity(0.16)) }
            .shadow(color: castsShadow ? Self.shadowColor : .clear, radius: 8, x: 4, y: 7)
    }
}

struct MakeBook: View {
    @EnvironmentObject private var archive: Archive
    @Environment(\.dismiss) private var dismiss
    let book: Volume?
    @State private var title: String
    @State private var ratio: Double
    @State private var photo: PhotosPickerItem?
    @State private var cover: Data?
    @State private var loading = false
    @State private var error = false

    init(book: Volume? = nil) {
        self.book = book
        _title = State(initialValue: book?.title ?? "")
        _ratio = State(initialValue: book?.proportion ?? 1.48)
        _cover = State(initialValue: book?.cover)
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                HStack {
                    RoundControl(icon: "xmark", label: "Cancelar") { dismiss() }
                    Spacer()
                    Text(book == nil ? "Nuevo libro" : "Editar libro").font(.system(.title2, design: .serif))
                    Spacer()
                    Button(book == nil ? "Crear" : "Guardar") {
                        var updated: Volume
                        if let book {
                            guard let existing = archive.books.first(where: { $0.id == book.id }) else { return }
                            updated = existing
                        } else {
                            updated = Volume(title: cleanTitle)
                        }
                        updated.title = cleanTitle
                        updated.proportion = ratio
                        updated.cover = cover
                        if archive.save(updated) { dismiss() }
                    }
                    .buttonStyle(GlassButton())
                    .disabled(cleanTitle.isEmpty || loading)
                }
                Hardcover(title: title, ratio: ratio, photo: cover).frame(width: 132)
                PhotosPicker(selection: $photo, matching: .images) {
                    Label("Elegir portada", systemImage: "photo")
                }
                if cover != nil && !loading {
                    Button("Quitar foto de portada") { cover = nil; photo = nil; error = false }
                        .buttonStyle(GlassButton())
                }
                if loading { ProgressView() }
                if error { Text("No se pudo cargar la foto.").foregroundStyle(.secondary) }
                TextField("Nombre del libro", text: $title)
                    .textFieldStyle(.roundedBorder)
                VStack(alignment: .leading) {
                    Text("Altura de la portada")
                    Slider(value: $ratio, in: 1.1...1.78) { Text("Altura de la portada") }
                }
            }
            .padding(24)
        }
        .background(ink.ignoresSafeArea())
        .foregroundStyle(paper)
        .task(id: photo) {
            guard let photo else { return }
            loading = true
            error = false
            let data = try? await photo.loadTransferable(type: Data.self)
            guard !Task.isCancelled else { return }
            if let data, let resized = photoData(data, maximum: 1100) {
                cover = resized
            } else {
                error = true
            }
            loading = false
        }
    }

    private var cleanTitle: String { title.trimmingCharacters(in: .whitespacesAndNewlines) }
}
