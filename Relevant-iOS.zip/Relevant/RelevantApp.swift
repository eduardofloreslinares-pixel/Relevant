import SwiftUI
import PhotosUI
import UIKit

let ink = Color(uiColor: UIColor { $0.userInterfaceStyle == .dark ? .black : .white })
let paper = Color(uiColor: .label)
let copper = Color(uiColor: .label)

struct GlassSurface<S: Shape>: ViewModifier {
    let shape: S
    var interactive = false

    @ViewBuilder func body(content: Content) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26, *) {
            content.glassEffect(interactive ? .regular.interactive() : .regular, in: shape)
        } else {
            content.background(.regularMaterial, in: shape)
        }
        #else
        content.background(.regularMaterial, in: shape)
        #endif
    }
}

struct GlassButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding(.horizontal, 15)
            .frame(minHeight: 42)
            .modifier(GlassSurface(shape: Capsule(), interactive: true))
            .opacity(configuration.isPressed ? 0.65 : 1)
    }
}

@main
struct RelevantApp: App {
    @StateObject private var archive = Archive()

    var body: some Scene {
        WindowGroup {
            LibraryView()
                .environmentObject(archive)
                .tint(copper)
                .alert("Relevant", isPresented: Binding(
                    get: { archive.problem != nil },
                    set: { if !$0 { archive.problem = nil } }
                )) {
                    Button("Entendido", role: .cancel) {}
                } message: {
                    Text(archive.problem ?? "")
                }
        }
    }
}

struct RoundControl: View {
    var icon: String
    var label: String
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 17, weight: .medium))
                .frame(width: 46, height: 46)
                .modifier(GlassSurface(shape: Circle(), interactive: true))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }
}

struct LibraryView: View {
    @EnvironmentObject private var archive: Archive
    @Namespace private var opening
    @State private var creating = false
    @State private var searching = false
    @State private var query = ""
    @FocusState private var searchFocus: Bool

    private var results: [Volume] {
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !term.isEmpty else { return archive.books }
        return archive.books.filter { book in
            book.title.localizedStandardContains(term) || book.pages.contains {
                $0.text.localizedStandardContains(term) || ($0.chapter?.localizedStandardContains(term) ?? false)
            }
        }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 23) {
                    HStack(spacing: 10) {
                        Text("Biblioteca")
                            .font(.system(size: 39, weight: .semibold, design: .serif))
                            .accessibilityAddTraits(.isHeader)
                        Spacer()
                        RoundControl(icon: searching ? "xmark" : "magnifyingglass", label: searching ? "Cerrar búsqueda" : "Buscar") {
                            searching.toggle()
                            searchFocus = searching
                            if !searching { query = "" }
                        }
                        RoundControl(icon: "plus", label: "Crear libro") { creating = true }
                    }
                    if searching {
                        TextField("Buscar en libros y páginas", text: $query)
                            .padding(13)
                            .modifier(GlassSurface(shape: RoundedRectangle(cornerRadius: 12)))
                            .focused($searchFocus)
                    }
                    Rectangle().fill(copper.opacity(0.26)).frame(height: 1)
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 140, maximum: 210), spacing: 22, alignment: .bottom)], spacing: 27) {
                        ForEach(results) { book in
                            NavigationLink {
                                ReaderView(book: book, initialPage: startPage(book))
                                    .navigationTransition(.zoom(sourceID: book.id, in: opening))
                            } label: {
                                Hardcover(title: book.title, ratio: book.proportion, photo: book.cover)
                                    .matchedTransitionSource(id: book.id, in: opening)
                                    .accessibilityLabel(book.title)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    if results.isEmpty {
                        Text(searching ? "Sin coincidencias" : "Crea tu primer libro con +")
                            .foregroundStyle(.secondary)
                    }
                }
                .frame(maxWidth: 760)
                .padding(.horizontal, 25)
                .padding(.vertical, 18)
                .frame(maxWidth: .infinity)
            }
            .background(ink.ignoresSafeArea())
            .foregroundStyle(paper)
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $creating) { MakeBook() }
        }
    }

    private func startPage(_ book: Volume) -> Int {
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !term.isEmpty, !book.title.localizedStandardContains(term) else { return book.position }
        return book.pages.firstIndex {
            $0.text.localizedStandardContains(term) || ($0.chapter?.localizedStandardContains(term) ?? false)
        } ?? book.position
    }
}

struct Hardcover: View {
    var title: String
    var ratio: Double
    var photo: Data?

    var body: some View {
        Color(white: 0.14)
            .aspectRatio(1 / ratio, contentMode: .fit)
            .overlay {
                GeometryReader { geometry in
                    if let photo, let image = UIImage(data: photo) {
                        Image(uiImage: image).resizable().scaledToFill()
                            .frame(width: geometry.size.width, height: geometry.size.height)
                    } else {
                        LinearGradient(colors: [Color(white: 0.29), Color(white: 0.08)],
                                       startPoint: .topLeading, endPoint: .bottomTrailing)
                    }
                }
                .clipped()
            }
            .overlay(alignment: .leading) {
                LinearGradient(stops: [
                    .init(color: .black.opacity(0.65), location: 0),
                    .init(color: .white.opacity(0.24), location: 0.22),
                    .init(color: .black.opacity(0.52), location: 0.70),
                    .init(color: .clear, location: 1)
                ], startPoint: .leading, endPoint: .trailing)
                .frame(width: 13)
            }
            .overlay {
                if photo == nil {
                    VStack(spacing: 13) {
                        Image(systemName: "sparkle").font(.system(size: 20, weight: .light))
                        Text(title.isEmpty ? "Sin título" : title)
                            .font(.system(size: 25, weight: .medium, design: .serif))
                            .multilineTextAlignment(.center)
                            .lineLimit(4)
                            .minimumScaleFactor(0.55)
                        Rectangle().fill(.white.opacity(0.60)).frame(width: 28, height: 1)
                    }
                    .foregroundStyle(.white)
                    .padding(.horizontal, 17)
                    .padding(.leading, 7)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .overlay {
                        RoundedRectangle(cornerRadius: 2).strokeBorder(.white.opacity(0.32))
                            .padding(.vertical, 13).padding(.leading, 19).padding(.trailing, 10)
                    }
                } else {
                    Text(title).foregroundStyle(.white).font(.system(.subheadline, design: .serif).weight(.semibold))
                        .lineLimit(2)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(10)
                        .padding(.leading, 6)
                        .background(.black.opacity(0.72))
                        .frame(maxHeight: .infinity, alignment: .bottom)
                }
            }
            .clipShape(.rect(topLeadingRadius: 3, bottomLeadingRadius: 3, bottomTrailingRadius: 6, topTrailingRadius: 6))
            .overlay { RoundedRectangle(cornerRadius: 5).strokeBorder(.white.opacity(0.16)) }
            .shadow(color: .black.opacity(0.48), radius: 8, x: 4, y: 7)
    }
}

struct MakeBook: View {
    @EnvironmentObject private var archive: Archive
    @Environment(\.dismiss) private var dismiss
    @State private var title = ""
    @State private var ratio = 1.48
    @State private var photo: PhotosPickerItem?
    @State private var cover: Data?
    @State private var loading = false
    @State private var error = false

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                HStack {
                    RoundControl(icon: "xmark", label: "Cancelar") { dismiss() }
                    Spacer()
                    Text("Nuevo libro").font(.system(.title2, design: .serif))
                    Spacer()
                    Button("Crear") {
                        if archive.save(Volume(title: cleanTitle, proportion: ratio, cover: cover)) { dismiss() }
                    }
                    .buttonStyle(GlassButton())
                    .disabled(cleanTitle.isEmpty || loading)
                }
                Hardcover(title: title, ratio: ratio, photo: cover).frame(width: 132)
                PhotosPicker(selection: $photo, matching: .images) {
                    Label("Elegir portada", systemImage: "photo")
                }
                if loading { ProgressView() }
                if error { Text("No se pudo cargar la foto.").foregroundStyle(.secondary) }
                TextField("Nombre del libro", text: $title)
                    .textFieldStyle(.roundedBorder)
                VStack(alignment: .leading) {
                    Text("Altura de la portada")
                    Slider(value: $ratio, in: 1.1...1.78) { Text("Altura de la portada") }
                }
            }
            .padding(24)
        }
        .background(ink.ignoresSafeArea())
        .foregroundStyle(paper)
        .task(id: photo) {
            guard let photo else { return }
            loading = true
            error = false
            let data = try? await photo.loadTransferable(type: Data.self)
            guard !Task.isCancelled else { return }
            if let data, let resized = photoData(data, maximum: 1100) {
                cover = resized
            } else {
                error = true
            }
            loading = false
        }
    }

    private var cleanTitle: String { title.trimmingCharacters(in: .whitespacesAndNewlines) }
}
