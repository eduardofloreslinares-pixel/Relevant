import SwiftUI
import UIKit

struct ReaderView: View {
    @EnvironmentObject private var archive: Archive
    @Environment(\.dismiss) private var dismiss
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var book: Volume
    @State private var controls = false
    @State private var chapters = false
    @State private var editing = false
    @State private var forward = true
    @State private var turning = false
    @State private var turnID = UUID()
    @State private var lastSize = CGSize.zero

    init(book: Volume, initialPage: Int) {
        var initial = book
        initial.position = min(max(initialPage, 0), initial.pages.count - 1)
        _book = State(initialValue: initial)
    }

    var body: some View {
        GeometryReader { geometry in
            let size = CGSize(width: max(1, min(650, geometry.size.width - 50)),
                              height: max(80, geometry.size.height - 140))
            ZStack(alignment: .top) {
                sheet(size)
                    .id(book.pages[book.position].id)
                    .transition(reduceMotion ? .opacity : .asymmetric(
                        insertion: .modifier(active: TurningPage(angle: forward ? 68 : -68, direction: forward ? 1 : -1),
                                             identity: TurningPage(angle: 0, direction: forward ? 1 : -1)),
                        removal: .opacity
                    ))
                    .zIndex(turning ? 5 : 2)
                    .allowsHitTesting(false)
                Rectangle().fill(.clear)
                    .contentShape(Rectangle())
                    .onTapGesture { toggleControls() }
                    .gesture(DragGesture(minimumDistance: 28).onEnded { drag in
                        guard abs(drag.translation.width) > abs(drag.translation.height) * 1.3 else { return }
                        turn(to: book.position + (drag.translation.width < 0 ? 1 : -1))
                    })
                    .accessibilityHidden(true)
                    .zIndex(3)
                VStack {
                    header
                    Spacer()
                    footer
                }
                .padding(.horizontal, 18)
                .zIndex(1)
                VStack {
                    if controls {
                        HStack {
                            RoundControl(icon: "xmark", label: "Cerrar libro") { dismiss() }
                            Spacer()
                            RoundControl(icon: "square.and.pencil", label: "Editar página") { editing = true }
                        }
                        Spacer()
                        HStack(spacing: 10) {
                            RoundControl(icon: "chevron.left", label: "Página anterior") { turn(to: book.position - 1) }
                                .disabled(book.position == 0)
                            RoundControl(icon: "chevron.right", label: "Página siguiente") { turn(to: book.position + 1) }
                                .disabled(book.position + 1 == book.pages.count)
                            Spacer()
                            RoundControl(icon: "ellipsis", label: "Capítulos") { chapters = true }
                        }
                    }
                }
                .padding(.horizontal, 18)
                .zIndex(4)
                .allowsHitTesting(!turning)
            }
            .onChange(of: size, initial: true) { _, size in
                lastSize = size
                book.paginate(to: size)
            }
            .accessibilityAction(named: Text("Mostrar u ocultar controles"), toggleControls)
            .accessibilityAction(named: Text("Página siguiente")) { turn(to: book.position + 1) }
            .accessibilityAction(named: Text("Página anterior")) { turn(to: book.position - 1) }
        }
        .foregroundStyle(paper)
        .background(ink.ignoresSafeArea())
        .toolbar(.hidden, for: .navigationBar)
        .sheet(isPresented: $chapters, onDismiss: {
            if book.paginate(to: lastSize) { archive.save(book) }
        }) {
            ContentsView(book: $book, jump: turn)
        }
        .fullScreenCover(isPresented: $editing) {
            PageEditor(book: book, pageSize: lastSize) { updated in
                guard archive.save(updated) else { return false }
                book = updated
                return true
            }
        }
    }

    private var header: some View {
        Text(book.title).font(.system(.subheadline, design: .serif))
            .foregroundStyle(.secondary).lineLimit(1).frame(height: 46)
            .frame(maxWidth: .infinity)
    }

    private var footer: some View {
        Text("\(book.position + 1)").font(.caption.monospacedDigit())
            .foregroundStyle(.secondary).frame(height: 46)
            .frame(maxWidth: .infinity)
    }

    private func sheet(_ size: CGSize) -> some View {
        let page = book.pages[book.position]
        return VStack(spacing: 0) {
            Color.clear.frame(height: 60)
            if let title = page.chapter {
                VStack(spacing: 4) {
                    Text(book.chapterNumber(at: book.position))
                        .font(.system(size: 14, weight: .semibold, design: .serif)).tracking(3)
                    Text(title).font(.system(size: 29, weight: .semibold, design: .serif))
                        .lineLimit(2).minimumScaleFactor(0.65)
                }
                .multilineTextAlignment(.center)
                .frame(width: size.width, height: 92)
                .accessibilityAddTraits(.isHeader)
            }
            let canvas = book.canvasSize(size, at: book.position)
            ZStack(alignment: .topLeading) {
                PageText(page: page, size: canvas)
                ForEach(page.objects ?? []) { object in
                    let rect = object.rect(in: canvas)
                    ObjectView(object: object).frame(width: rect.width, height: rect.height)
                        .position(x: rect.midX, y: rect.midY)
                }
            }
            .frame(width: canvas.width, height: canvas.height)
            .clipped()
            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private func toggleControls() {
        withAnimation(.easeInOut(duration: 0.18)) { controls.toggle() }
    }

    private func turn(to target: Int) {
        guard book.pages.indices.contains(target), target != book.position else { return }
        forward = target > book.position
        let token = UUID()
        turnID = token
        turning = !reduceMotion
        withAnimation(.easeInOut(duration: 0.34), completionCriteria: .removed) {
            book.position = target
        } completion: {
            if turnID == token { turning = false }
        }
        archive.save(book)
    }
}

private struct TurningPage: AnimatableModifier {
    var angle: Double
    var direction: Double

    var animatableData: Double {
        get { angle }
        set { angle = newValue }
    }

    func body(content: Content) -> some View {
        content
            .background(alignment: .center) { ink.opacity(min(1, abs(angle) / 12)) }
            .rotation3DEffect(.degrees(angle), axis: (x: 0, y: 1, z: 0),
                              anchor: direction < 0 ? .leading : .trailing, perspective: 0.55)
            .offset(x: direction * abs(angle) * 3, y: -abs(angle) * 1.5)
    }
}

struct ContentsView: View {
    @EnvironmentObject private var archive: Archive
    @Environment(\.dismiss) private var dismiss
    @Binding var book: Volume
    let jump: (Int) -> Void
    @State private var naming = false
    @State private var name = ""

    private var activeChapter: Int? {
        book.pages.indices.last { $0 <= book.position && book.pages[$0].chapter != nil }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                RoundControl(icon: "xmark", label: "Cerrar índice") { dismiss() }
                Spacer()
                Text("Capítulos").font(.system(.title, design: .serif))
                Spacer()
                RoundControl(icon: "bookmark", label: "Marcar página como inicio de capítulo") {
                    name = book.pages[book.position].chapter ?? ""
                    naming = true
                }
            }
            Text(book.title + " · Página \(book.position + 1)")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            ScrollView {
                VStack(spacing: 6) {
                    ForEach(Array(book.pages.enumerated()), id: \.element.id) { index, page in
                        if let chapter = page.chapter {
                            Button {
                                jump(index)
                                dismiss()
                            } label: {
                                HStack {
                                    Text(book.chapterNumber(at: index)).font(.system(.subheadline, design: .serif))
                                        .frame(width: 36)
                                    Text(chapter).font(.system(.title3, design: .serif))
                                    Spacer()
                                    Text("\(index + 1)").monospacedDigit().foregroundStyle(.secondary)
                                }
                                .padding(14)
                                .background(index == activeChapter ? copper.opacity(0.13) : .clear,
                                            in: RoundedRectangle(cornerRadius: 10))
                            }
                            .buttonStyle(.plain)
                            Divider()
                        }
                    }
                }
            }
            Button {
                name = book.pages[book.position].chapter ?? ""
                naming = true
            } label: {
                Label(book.pages[book.position].chapter == nil ? "Iniciar capítulo en esta página" : "Editar capítulo de esta página",
                      systemImage: "bookmark")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(GlassButton())
        }
        .padding(23)
        .foregroundStyle(paper)
        .background(ink.ignoresSafeArea())
        .alert("Inicio de capítulo", isPresented: $naming) {
            TextField("Nombre del capítulo", text: $name)
            Button("Cancelar", role: .cancel) {}
            if book.pages[book.position].chapter != nil {
                Button("Quitar marca", role: .destructive) { mark(nil) }
            }
            Button("Listo") {
                let title = name.trimmingCharacters(in: .whitespacesAndNewlines)
                if !title.isEmpty { mark(title) }
            }
        } message: {
            Text("Página \(book.position + 1)")
        }
    }

    private func mark(_ chapter: String?) {
        var updated = book
        updated.pages[book.position].chapter = chapter
        if archive.save(updated) { book = updated }
    }
}

struct PageText: UIViewRepresentable {
    let page: Folio
    let size: CGSize

    func makeUIView(context: Context) -> UITextView {
        let view = PageDocument.textView()
        view.isEditable = false
        view.isSelectable = false
        view.isScrollEnabled = false
        return view
    }

    func updateUIView(_ view: UITextView, context: Context) {
        view.textContainer.exclusionPaths = PageDocument.paths(page.objects ?? [], in: size)
        view.attributedText = PageDocument.contents(of: page)
    }
}
