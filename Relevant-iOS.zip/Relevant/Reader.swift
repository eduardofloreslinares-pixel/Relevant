import SwiftUI
import UIKit

struct ReaderView: View {
    @EnvironmentObject private var archive: Archive
    @Environment(\.dismiss) private var dismiss
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var book: Volume
    @State private var controls = false
    @State private var chapters = false
    @State private var editing = false
    @State private var turnTarget: Int?
    @State private var turnProgress = 0.0
    @State private var settlingTurn = false
    @State private var closing = false
    @State private var lastSize = CGSize.zero

    init(book: Volume, initialPage: Int) {
        var initial = book
        initial.position = min(max(initialPage, 0), initial.pages.count - 1)
        _book = State(initialValue: initial)
    }

    var body: some View {
        GeometryReader { geometry in
            let size = CGSize(width: max(1, min(650, geometry.size.width - 50)),
                              height: max(80, geometry.size.height - 140))
            VStack(spacing: 0) {
                header
                ReaderTouchArea(tap: toggleControls, pan: { movement, velocity, state in
                    trackPageDrag(movement, velocity: velocity, state: state, width: geometry.size.width)
                })
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .accessibilityHidden(true)
                footer
            }
            .background(alignment: .top) {
                ZStack {
                    pageFace(size, at: book.position)
                    if let target = turnTarget, book.pages.indices.contains(target) {
                        let direction = target > book.position ? 1.0 : -1.0
                        pageFace(size, at: target)
                            .background(ink)
                            .modifier(IncomingPage(progress: turnProgress, direction: direction,
                                                   width: geometry.size.width, reduceMotion: reduceMotion))
                            .accessibilityHidden(true)
                    }
                }
                .clipped()
                .allowsHitTesting(false)
            }
            .overlay {
                if closing {
                    Hardcover(title: book.title,
                              ratio: Double(geometry.size.height / max(geometry.size.width, 1)),
                              photo: book.cover, castsShadow: false)
                        .frame(width: geometry.size.width, height: geometry.size.height)
                        .allowsHitTesting(false)
                        .accessibilityHidden(true)
                        .transition(.opacity)
                }
            }
            .allowsHitTesting(!closing)
            .onChange(of: size, initial: true) { _, size in
                lastSize = size
                book.paginate(to: size)
            }
            .accessibilityAction(named: Text("Mostrar u ocultar controles"), toggleControls)
            .accessibilityAction(named: Text("Página siguiente")) { turn(to: book.position + 1) }
            .accessibilityAction(named: Text("Página anterior")) { turn(to: book.position - 1) }
        }
        .foregroundStyle(paper)
        .background(ink.ignoresSafeArea())
        .toolbar(.hidden, for: .navigationBar)
        .sheet(isPresented: $chapters, onDismiss: {
            if book.paginate(to: lastSize) { archive.save(book) }
        }) {
            ContentsView(book: $book, jump: turn)
        }
        .fullScreenCover(isPresented: $editing) {
            PageEditor(book: book, pageSize: lastSize) { updated in
                guard archive.save(updated) else { return false }
                book = updated
                return true
            }
        }
    }

    private var header: some View {
        ZStack {
            Text(book.title)
                .font(.system(.subheadline, design: .serif))
                .foregroundStyle(.secondary)
                .lineLimit(1)
                .padding(.horizontal, 72)
                .allowsHitTesting(false)
            if controls {
                HStack {
                    RoundControl(icon: "xmark", label: "Cerrar libro", action: closeBook)
                    Spacer()
                    RoundControl(icon: "square.and.pencil", label: "Editar página") { editing = true }
                }
                .transition(chromeTransition(edge: .top))
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: 46)
        .padding(.horizontal, 18)
    }

    private var footer: some View {
        ZStack(alignment: .trailing) {
            Text("\(book.position + 1)")
                .font(.caption.monospacedDigit())
                .foregroundStyle(.secondary)
                .frame(maxWidth: .infinity)
                .allowsHitTesting(false)
            if controls {
                RoundControl(icon: "ellipsis", label: "Capítulos") { chapters = true }
                    .transition(chromeTransition(edge: .bottom))
            }
        }
        .frame(height: 46)
        .padding(.horizontal, 18)
    }

    private func closeBook() {
        guard !closing else { return }
        if reduceMotion {
            dismiss()
            return
        }
        withAnimation(.easeOut(duration: 0.14)) {
            closing = true
        } completion: {
            dismiss()
        }
    }

    private func chromeTransition(edge: Edge) -> AnyTransition {
        reduceMotion ? .opacity : .move(edge: edge).combined(with: .opacity)
    }

    private func pageFace(_ size: CGSize, at position: Int) -> some View {
        let page = book.pages[position]
        return VStack(spacing: 0) {
            Color.clear.frame(height: 60)
            if let title = page.chapter {
                VStack(spacing: 4) {
                    Text(book.chapterNumber(at: position))
                        .font(.system(size: 14, weight: .semibold, design: .serif)).tracking(3)
                    Text(title).font(.system(size: 29, weight: .semibold, design: .serif))
                        .lineLimit(2).minimumScaleFactor(0.65)
                }
                .multilineTextAlignment(.center)
                .frame(width: size.width, height: 92)
                .accessibilityAddTraits(.isHeader)
            }
            let canvas = book.canvasSize(size, at: position)
            ZStack(alignment: .topLeading) {
                PageText(page: page, size: canvas)
                    .frame(width: canvas.width, height: canvas.height)
                ForEach(page.objects ?? []) { object in
                    let rect = object.rect(in: canvas)
                    ObjectView(object: object).frame(width: rect.width, height: rect.height)
                        .position(x: rect.midX, y: rect.midY)
                }
            }
            .frame(width: canvas.width, height: canvas.height)
            .clipped()
            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private func toggleControls() {
        setControls(visible: !controls)
    }

    private func setControls(visible: Bool) {
        guard controls != visible else { return }
        withAnimation(.easeInOut(duration: 0.22)) { controls = visible }
    }

    private func trackPageDrag(_ distance: CGFloat, velocity: CGFloat,
                               state: UIGestureRecognizer.State, width: CGFloat) {
        guard !settlingTurn else { return }
        switch state {
        case .began, .changed:
            let target = book.position + (distance < 0 ? 1 : -1)
            guard distance != 0, book.pages.indices.contains(target) else {
                turnTarget = nil
                turnProgress = 0
                return
            }
            turnTarget = target
            turnProgress = Double(min(1, abs(distance) / max(width * 0.85, 1)))
        case .ended:
            guard let target = turnTarget else { return }
            let direction: CGFloat = target > book.position ? -1 : 1
            let projected = (distance + velocity * 0.14) * direction
            let completes = distance * direction >= 24 && projected >= width * 0.34
            settlePageTurn(completes ? target : nil)
        case .cancelled, .failed:
            if turnTarget != nil { settlePageTurn(nil) }
        default:
            break
        }
    }

    private func settlePageTurn(_ destination: Int?) {
        settlingTurn = true
        withAnimation(.easeOut(duration: reduceMotion ? 0.14 : 0.24)) {
            turnProgress = destination == nil ? 0 : 1
        } completion: {
            if let destination { turn(to: destination) }
            turnTarget = nil
            turnProgress = 0
            settlingTurn = false
        }
    }

    private func turn(to target: Int) {
        guard book.pages.indices.contains(target), target != book.position else { return }
        book.position = target
        archive.save(book)
    }
}

private struct ReaderTouchArea: UIViewRepresentable {
    var tap: () -> Void
    var pan: (CGFloat, CGFloat, UIGestureRecognizer.State) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(tap: tap, pan: pan) }

    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .clear
        let coordinator = context.coordinator
        let pan = UIPanGestureRecognizer(target: coordinator, action: #selector(Coordinator.didPan(_:)))
        pan.maximumNumberOfTouches = 1
        pan.delegate = coordinator
        let tap = UITapGestureRecognizer(target: coordinator, action: #selector(Coordinator.didTap(_:)))
        tap.require(toFail: pan)
        view.addGestureRecognizer(pan)
        view.addGestureRecognizer(tap)
        return view
    }

    func updateUIView(_ view: UIView, context: Context) {
        context.coordinator.tap = tap
        context.coordinator.pan = pan
    }

    @MainActor
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        var tap: () -> Void
        var pan: (CGFloat, CGFloat, UIGestureRecognizer.State) -> Void

        init(tap: @escaping () -> Void, pan: @escaping (CGFloat, CGFloat, UIGestureRecognizer.State) -> Void) {
            self.tap = tap
            self.pan = pan
        }

        func gestureRecognizerShouldBegin(_ recognizer: UIGestureRecognizer) -> Bool {
            guard let pan = recognizer as? UIPanGestureRecognizer else { return true }
            let movement = pan.translation(in: pan.view)
            let direction = movement == .zero ? pan.velocity(in: pan.view) : movement
            // Decline vertical pans before recognition so the navigation zoom can track the finger.
            return abs(direction.x) > 1.3 * abs(direction.y)
        }

        @objc func didPan(_ pan: UIPanGestureRecognizer) {
            self.pan(pan.translation(in: pan.view).x, pan.velocity(in: pan.view).x, pan.state)
        }

        @objc func didTap(_ recognizer: UITapGestureRecognizer) {
            if recognizer.state == .ended { tap() }
        }
    }
}

private struct IncomingPage: AnimatableModifier {
    var progress: Double
    let direction: Double
    let width: CGFloat
    let reduceMotion: Bool

    var animatableData: Double {
        get { progress }
        set { progress = newValue }
    }

    func body(content: Content) -> some View {
        let remaining = 1 - progress
        content
            .shadow(color: .black.opacity(reduceMotion ? 0 : 0.28 * sin(.pi * progress)),
                    radius: 10, x: CGFloat(-direction * 6))
            .rotation3DEffect(.degrees(reduceMotion ? 0 : direction * 42 * remaining),
                              axis: (x: 0, y: 1, z: 0),
                              anchor: direction > 0 ? .trailing : .leading, perspective: 0.16)
            .offset(x: reduceMotion ? 0 : CGFloat(direction * remaining) * width)
            .opacity(reduceMotion ? progress : 1)
    }
}

struct ContentsView: View {
    @EnvironmentObject private var archive: Archive
    @Environment(\.dismiss) private var dismiss
    @Binding var book: Volume
    let jump: (Int) -> Void
    @State private var naming = false
    @State private var name = ""

    private var activeChapter: Int? {
        book.pages.indices.last { $0 <= book.position && book.pages[$0].chapter != nil }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                RoundControl(icon: "xmark", label: "Cerrar índice") { dismiss() }
                Spacer()
                Text("Capítulos").font(.system(.title, design: .serif))
                Spacer()
                RoundControl(icon: "bookmark", label: "Marcar página como inicio de capítulo") {
                    name = book.pages[book.position].chapter ?? ""
                    naming = true
                }
            }
            Text(book.title + " · Página \(book.position + 1)")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            ScrollView {
                VStack(spacing: 6) {
                    ForEach(Array(book.pages.enumerated()), id: \.element.id) { index, page in
                        if let chapter = page.chapter {
                            Button {
                                jump(index)
                                dismiss()
                            } label: {
                                HStack {
                                    Text(book.chapterNumber(at: index)).font(.system(.subheadline, design: .serif))
                                        .frame(width: 36)
                                    Text(chapter).font(.system(.title3, design: .serif))
                                    Spacer()
                                    Text("\(index + 1)").monospacedDigit().foregroundStyle(.secondary)
                                }
                                .padding(14)
                                .contentShape(Rectangle())
                                .background(index == activeChapter ? copper.opacity(0.13) : .clear,
                                            in: RoundedRectangle(cornerRadius: 10))
                            }
                            .buttonStyle(.plain)
                            Divider()
                        }
                    }
                }
            }
            Button {
                name = book.pages[book.position].chapter ?? ""
                naming = true
            } label: {
                Label(book.pages[book.position].chapter == nil ? "Iniciar capítulo en esta página" : "Editar capítulo de esta página",
                      systemImage: "bookmark")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(GlassButton())
        }
        .padding(23)
        .foregroundStyle(paper)
        .background(ink.ignoresSafeArea())
        .alert("Inicio de capítulo", isPresented: $naming) {
            TextField("Nombre del capítulo", text: $name)
            Button("Cancelar", role: .cancel) {}
            if book.pages[book.position].chapter != nil {
                Button("Quitar marca", role: .destructive) { mark(nil) }
            }
            Button("Listo") {
                let title = name.trimmingCharacters(in: .whitespacesAndNewlines)
                if !title.isEmpty { mark(title) }
            }
        } message: {
            Text("Página \(book.position + 1)")
        }
    }

    private func mark(_ chapter: String?) {
        var updated = book
        updated.pages[book.position].chapter = chapter
        if archive.save(updated) { book = updated }
    }
}

struct PageText: UIViewRepresentable {
    let page: Folio
    let size: CGSize

    func makeUIView(context: Context) -> PrintedPage {
        let view = PrintedPage()
        view.isOpaque = false
        view.backgroundColor = .clear
        view.isUserInteractionEnabled = false
        view.isAccessibilityElement = true
        return view
    }

    func updateUIView(_ view: PrintedPage, context: Context) {
        view.text = PageDocument.contents(of: page)
        view.pageSize = size
        view.objects = page.objects ?? []
        view.accessibilityLabel = page.text
        view.setNeedsDisplay()
    }

    func sizeThatFits(_ proposal: ProposedViewSize, uiView: PrintedPage, context: Context) -> CGSize? {
        size
    }
}

final class PrintedPage: UIView {
    var text = NSAttributedString(string: "")
    var pageSize = CGSize.zero
    var objects: [PageObject] = []

    override func draw(_ rect: CGRect) {
        guard text.length > 0, let context = UIGraphicsGetCurrentContext() else { return }
        let inked = NSMutableAttributedString(attributedString: text)
        inked.addAttribute(.foregroundColor, value: UIColor.label.resolvedColor(with: traitCollection),
                           range: NSRange(location: 0, length: inked.length))
        let page = PageTextLayout(text: inked, size: pageSize, objects: objects)
        context.clip(to: CGRect(origin: .zero, size: pageSize))
        page.manager.drawBackground(forGlyphRange: page.visibleGlyphs, at: .zero)
        page.manager.drawGlyphs(forGlyphRange: page.visibleGlyphs, at: .zero)
    }
}
