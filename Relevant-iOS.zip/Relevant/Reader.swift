import SwiftUI
import UIKit

struct ReaderView: View {
    @EnvironmentObject private var archive: Archive
    @Environment(\.dismiss) private var dismiss
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var book: Volume
    @State private var controls = false
    @State private var chapters = false
    @State private var editing = false
    @State private var forward = true

    init(book: Volume, initialPage: Int) {
        var initial = book
        initial.position = min(max(initialPage, 0), initial.pages.count - 1)
        _book = State(initialValue: initial)
    }

    var body: some View {
        VStack(spacing: 3) {
            ZStack {
                Text(book.title)
                    .font(.system(.subheadline, design: .serif))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .padding(.horizontal, 58)
                    .accessibilityAddTraits(.isHeader)
                if controls {
                    HStack {
                        RoundControl(icon: "xmark", label: "Cerrar libro") { dismiss() }
                        Spacer()
                        RoundControl(icon: "square.and.pencil", label: "Editar página") { editing = true }
                    }
                    .transition(.opacity)
                }
            }
            .frame(height: 48)
            .padding(.horizontal, 18)

            GeometryReader { geometry in
                ZStack {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 21) {
                            if let chapter = book.pages[book.position].chapter {
                                Text(chapter)
                                    .font(.system(.largeTitle, design: .serif).weight(.medium))
                                    .foregroundStyle(copper)
                                    .accessibilityAddTraits(.isHeader)
                            }
                            if book.pages[book.position].text.isEmpty && book.pages[book.position].richText == nil {
                                Text("Página en blanco").font(.system(.body, design: .serif))
                                    .foregroundStyle(.secondary)
                            } else {
                                PageText(page: book.pages[book.position])
                            }
                        }
                        .padding(.horizontal, 30)
                        .padding(.vertical, 21)
                        .frame(maxWidth: 650)
                        .frame(maxWidth: .infinity, minHeight: geometry.size.height, alignment: .top)
                        .contentShape(Rectangle())
                    }
                    .id(book.pages[book.position].id)
                    .transition(reduceMotion ? .opacity : .asymmetric(
                        insertion: .modifier(active: TurningPage(angle: forward ? 38 : -38), identity: TurningPage(angle: 0)),
                        removal: .modifier(active: TurningPage(angle: forward ? -38 : 38), identity: TurningPage(angle: 0))
                    ))
                }
                .clipped()
                .simultaneousGesture(TapGesture().onEnded { toggleControls() })
                .simultaneousGesture(DragGesture(minimumDistance: 32).onEnded { drag in
                    guard abs(drag.translation.width) > abs(drag.translation.height) * 1.4,
                          drag.startLocation.x > 20 else { return }
                    turn(to: book.position + (drag.translation.width < 0 ? 1 : -1))
                })
                .accessibilityAction(named: Text("Mostrar u ocultar controles"), toggleControls)
                .accessibilityAction(named: Text("Página siguiente")) { turn(to: book.position + 1) }
                .accessibilityAction(named: Text("Página anterior")) { turn(to: book.position - 1) }
            }

            ZStack {
                Text("\(book.position + 1)")
                    .font(.system(.subheadline, design: .monospaced))
                    .foregroundStyle(.secondary)
                    .accessibilityLabel("Página \(book.position + 1) de \(book.pages.count)")
                if controls {
                    HStack(spacing: 10) {
                        RoundControl(icon: "chevron.left", label: "Página anterior") { turn(to: book.position - 1) }
                            .disabled(book.position == 0)
                            .opacity(book.position == 0 ? 0.32 : 1)
                        RoundControl(icon: "chevron.right", label: "Página siguiente") { turn(to: book.position + 1) }
                            .disabled(book.position == book.pages.count - 1)
                            .opacity(book.position == book.pages.count - 1 ? 0.32 : 1)
                        Spacer()
                        RoundControl(icon: "ellipsis", label: "Capítulos") { chapters = true }
                    }
                    .padding(.horizontal, 18)
                    .transition(.opacity)
                }
            }
            .frame(height: 50)
        }
        .foregroundStyle(paper)
        .background(ink.ignoresSafeArea())
        .toolbar(.hidden, for: .navigationBar)
        .statusBarHidden(!controls)
        .sheet(isPresented: $chapters) {
            ContentsView(book: $book, jump: turn)
        }
        .fullScreenCover(isPresented: $editing) {
            PageEditor(book: book) { updated in
                guard archive.save(updated) else { return false }
                book = updated
                return true
            }
        }
    }

    private func toggleControls() {
        withAnimation(.easeInOut(duration: 0.18)) { controls.toggle() }
    }

    private func turn(to target: Int) {
        guard book.pages.indices.contains(target), target != book.position else { return }
        forward = target > book.position
        withAnimation(.easeInOut(duration: 0.24)) { book.position = target }
        archive.save(book)
    }
}

private struct TurningPage: AnimatableModifier {
    var angle: Double

    var animatableData: Double {
        get { angle }
        set { angle = newValue }
    }

    func body(content: Content) -> some View {
        content
            .rotation3DEffect(.degrees(angle), axis: (x: 0, y: 1, z: 0),
                              anchor: angle < 0 ? .leading : .trailing, perspective: 0.6)
            .opacity(max(0, 1 - abs(angle) / 38))
    }
}

struct ContentsView: View {
    @EnvironmentObject private var archive: Archive
    @Environment(\.dismiss) private var dismiss
    @Binding var book: Volume
    let jump: (Int) -> Void
    @State private var naming = false
    @State private var name = ""

    private var activeChapter: Int? {
        book.pages.indices.last { $0 <= book.position && book.pages[$0].chapter != nil }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                RoundControl(icon: "xmark", label: "Cerrar índice") { dismiss() }
                Spacer()
                Text("Capítulos").font(.system(.title, design: .serif))
                Spacer()
                RoundControl(icon: "bookmark", label: "Marcar página como inicio de capítulo") {
                    name = book.pages[book.position].chapter ?? ""
                    naming = true
                }
            }
            Text(book.title + " · Página \(book.position + 1)")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            ScrollView {
                VStack(spacing: 6) {
                    ForEach(Array(book.pages.enumerated()), id: \.element.id) { index, page in
                        if let chapter = page.chapter {
                            Button {
                                jump(index)
                                dismiss()
                            } label: {
                                HStack {
                                    Text(chapter).font(.system(.title3, design: .serif))
                                    Spacer()
                                    Text("\(index + 1)").monospacedDigit().foregroundStyle(.secondary)
                                }
                                .padding(14)
                                .background(index == activeChapter ? copper.opacity(0.13) : .clear,
                                            in: RoundedRectangle(cornerRadius: 10))
                            }
                            .buttonStyle(.plain)
                            Divider()
                        }
                    }
                }
            }
            Button {
                name = book.pages[book.position].chapter ?? ""
                naming = true
            } label: {
                Label(book.pages[book.position].chapter == nil ? "Iniciar capítulo en esta página" : "Editar capítulo de esta página",
                      systemImage: "bookmark")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
        }
        .padding(23)
        .foregroundStyle(paper)
        .background(ink.ignoresSafeArea())
        .alert("Inicio de capítulo", isPresented: $naming) {
            TextField("Nombre del capítulo", text: $name)
            Button("Cancelar", role: .cancel) {}
            if book.pages[book.position].chapter != nil {
                Button("Quitar marca", role: .destructive) { mark(nil) }
            }
            Button("Listo") {
                let title = name.trimmingCharacters(in: .whitespacesAndNewlines)
                if !title.isEmpty { mark(title) }
            }
        } message: {
            Text("Página \(book.position + 1)")
        }
    }

    private func mark(_ chapter: String?) {
        var updated = book
        updated.pages[book.position].chapter = chapter
        if archive.save(updated) { book = updated }
    }
}

struct PageText: UIViewRepresentable {
    let page: Folio

    func makeUIView(context: Context) -> UITextView {
        let view = UITextView()
        view.isEditable = false
        view.isSelectable = true
        view.isScrollEnabled = false
        view.backgroundColor = .clear
        view.textContainerInset = .zero
        view.textContainer.lineFragmentPadding = 0
        view.linkTextAttributes = [.foregroundColor: UIColor(copper), .underlineStyle: NSUnderlineStyle.single.rawValue]
        view.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        return view
    }

    func updateUIView(_ view: UITextView, context: Context) {
        let rendered = NSMutableAttributedString(attributedString: PageDocument.contents(of: page))
        let full = NSRange(location: 0, length: rendered.length)
        rendered.enumerateAttribute(.font, in: full) { value, range, _ in
            let old = value as? UIFont ?? PageDocument.font
            let traits = old.fontDescriptor.symbolicTraits.intersection([.traitBold, .traitItalic])
            if let serif = old.fontDescriptor.withDesign(.serif),
               let styled = serif.withSymbolicTraits(traits) {
                rendered.addAttribute(.font, value: UIFont(descriptor: styled, size: max(21, old.pointSize + 2)), range: range)
            }
        }
        rendered.addAttribute(.foregroundColor, value: UIColor(paper), range: full)
        view.attributedText = rendered
    }

    func sizeThatFits(_ proposal: ProposedViewSize, uiView: UITextView, context: Context) -> CGSize? {
        guard let width = proposal.width else { return nil }
        return uiView.sizeThatFits(CGSize(width: width, height: .greatestFiniteMagnitude))
    }
}
