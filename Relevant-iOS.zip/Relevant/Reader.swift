import SwiftUI
import UIKit

struct ReaderView: View {
    @EnvironmentObject private var archive: Archive
    @Environment(\.dismiss) private var dismiss
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var book: Volume
    @State private var controls = false
    @State private var chapters = false
    @State private var editing = false
    @State private var lastSize = CGSize.zero

    let onClose: (AnyView, CGRect, () -> Void) -> Void

    init(book: Volume, initialPage: Int, onClose: @escaping (AnyView, CGRect, () -> Void) -> Void) {
        self.onClose = onClose
        var initial = book
        initial.position = min(max(initialPage, 0), initial.pages.count - 1)
        _book = State(initialValue: initial)
    }

    var body: some View {
        GeometryReader { geometry in
            let size = CGSize(width: max(1, min(650, geometry.size.width - 50)),
                              height: max(80, geometry.size.height - 140))
            ZStack {
                PaperPager(position: book.position, count: book.pages.count,
                           onTurn: turn, onTap: toggleControls) { index in
                    AnyView(
                        pageFace(size, at: index)
                            .padding(.top, geometry.safeAreaInsets.top)
                            .padding(.bottom, geometry.safeAreaInsets.bottom)
                            .foregroundStyle(paper)
                            .background(ink)
                            .ignoresSafeArea()
                    )
                }
                .ignoresSafeArea(.container, edges: [.top, .bottom])
                if controls {
                    VStack(spacing: 0) {
                        header {
                            let page = AnyView(pageFace(size, at: book.position).foregroundStyle(paper))
                            onClose(page, geometry.frame(in: .global)) { dismiss() }
                        }
                        .transition(chromeTransition(edge: .top))
                        Spacer()
                        footer.transition(chromeTransition(edge: .bottom))
                    }
                }
            }
            .onChange(of: size, initial: true) { _, size in
                lastSize = size
                book.paginate(to: size)
            }
            .accessibilityAction(named: Text("Mostrar u ocultar controles"), toggleControls)
            .accessibilityAction(named: Text("Página siguiente")) { turn(to: book.position + 1) }
            .accessibilityAction(named: Text("Página anterior")) { turn(to: book.position - 1) }
        }
        .foregroundStyle(paper)
        .background(ink.ignoresSafeArea())
        .toolbar(.hidden, for: .navigationBar)
        .sheet(isPresented: $chapters, onDismiss: {
            if book.paginate(to: lastSize) { archive.save(book) }
        }) {
            ContentsView(book: $book, jump: turn)
        }
        .fullScreenCover(isPresented: $editing) {
            PageEditor(book: book, pageSize: lastSize) { updated in
                guard archive.save(updated) else { return false }
                book = updated
                return true
            }
        }
    }

    private func header(close: @escaping () -> Void) -> some View {
        HStack {
            RoundControl(icon: "xmark", label: "Cerrar libro", action: close)
            Spacer()
            RoundControl(icon: "square.and.pencil", label: "Editar página") { editing = true }
        }
        .frame(maxWidth: .infinity)
        .frame(height: 46)
        .padding(.horizontal, 18)
    }

    private var footer: some View {
        HStack {
            Spacer()
            RoundControl(icon: "ellipsis", label: "Capítulos") { chapters = true }
        }
        .frame(height: 46)
        .padding(.horizontal, 18)
    }

    private func chromeTransition(edge: Edge) -> AnyTransition {
        reduceMotion ? .opacity : .move(edge: edge).combined(with: .opacity)
    }

    private func pageFace(_ size: CGSize, at position: Int) -> some View {
        let page = book.pages[position]
        return VStack(spacing: 0) {
            Text(book.title)
                .font(.system(.subheadline, design: .serif))
                .foregroundStyle(.secondary)
                .lineLimit(1)
                .padding(.horizontal, 72)
                .frame(height: 46)
                .padding(.bottom, 14)
            if let title = page.chapter {
                VStack(spacing: 4) {
                    Text(book.chapterNumber(at: position))
                        .font(.system(size: 14, weight: .semibold, design: .serif)).tracking(3)
                    Text(title).font(.system(size: 29, weight: .semibold, design: .serif))
                        .lineLimit(2).minimumScaleFactor(0.65)
                }
                .multilineTextAlignment(.center)
                .frame(width: size.width, height: 92)
                .accessibilityAddTraits(.isHeader)
            }
            let canvas = book.canvasSize(size, at: position)
            ZStack(alignment: .topLeading) {
                PageText(page: page, size: canvas)
                    .frame(width: canvas.width, height: canvas.height)
                ForEach(page.objects ?? []) { object in
                    let rect = object.rect(in: canvas)
                    ObjectView(object: object).frame(width: rect.width, height: rect.height)
                        .position(x: rect.midX, y: rect.midY)
                }
            }
            .frame(width: canvas.width, height: canvas.height)
            .clipped()
            Spacer(minLength: 0)
            Text("\(position + 1)")
                .font(.caption.monospacedDigit())
                .foregroundStyle(.secondary)
                .frame(height: 46)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private func toggleControls() {
        setControls(visible: !controls)
    }

    private func setControls(visible: Bool) {
        guard controls != visible else { return }
        withAnimation(.easeInOut(duration: 0.22)) { controls = visible }
    }

    private func turn(to target: Int) {
        guard book.pages.indices.contains(target), target != book.position else { return }
        book.position = target
        archive.save(book)
    }
}

private struct PaperPager: UIViewControllerRepresentable {
    let position: Int
    let count: Int
    let onTurn: (Int) -> Void
    let onTap: () -> Void
    let face: (Int) -> AnyView

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

    func makeUIViewController(context: Context) -> UIPageViewController {
        let pager = UIPageViewController(
            transitionStyle: .pageCurl, navigationOrientation: .horizontal,
            options: [.spineLocation: UIPageViewController.SpineLocation.min.rawValue]
        )
        pager.isDoubleSided = false
        pager.view.backgroundColor = UIColor(ink)
        pager.setViewControllers([Page(position: position, face: face(position))], direction: .forward, animated: false)
        pager.dataSource = context.coordinator
        pager.delegate = context.coordinator

        // Keep horizontal page drags and reserve a single tap for the reader controls.
        for case let tap as UITapGestureRecognizer in pager.gestureRecognizers {
            tap.isEnabled = false
        }
        let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.didTap))
        tap.cancelsTouchesInView = false
        for case let pan as UIPanGestureRecognizer in pager.gestureRecognizers {
            tap.require(toFail: pan)
        }
        pager.view.addGestureRecognizer(tap)
        return pager
    }

    func updateUIViewController(_ pager: UIPageViewController, context: Context) {
        let coordinator = context.coordinator
        coordinator.parent = self
        guard !coordinator.isTurning else { return }
        if let current = pager.viewControllers?.first as? Page, current.position == position {
            current.rootView = face(position)
        } else {
            let previous = (pager.viewControllers?.first as? Page)?.position ?? position
            pager.setViewControllers([Page(position: position, face: face(position))],
                                     direction: position >= previous ? .forward : .reverse, animated: false)
        }
    }

    private final class Page: UIHostingController<AnyView> {
        let position: Int

        init(position: Int, face: AnyView) {
            self.position = position
            super.init(rootView: face)
        }

        @available(*, unavailable)
        required dynamic init?(coder: NSCoder) { fatalError("Use init(position:face:)") }

        override func viewDidLoad() {
            super.viewDidLoad()
            view.backgroundColor = UIColor(ink)
        }
    }

    @MainActor
    final class Coordinator: NSObject, UIPageViewControllerDataSource, UIPageViewControllerDelegate {
        var parent: PaperPager
        var isTurning = false

        init(parent: PaperPager) {
            self.parent = parent
        }

        @objc func didTap() {
            if !isTurning { parent.onTap() }
        }

        private func neighbor(of controller: UIViewController, step: Int) -> Page? {
            guard let current = controller as? Page else { return nil }
            let position = current.position + step
            guard (0..<parent.count).contains(position) else { return nil }
            return Page(position: position, face: parent.face(position))
        }

        func pageViewController(_ pageViewController: UIPageViewController,
                                viewControllerBefore viewController: UIViewController) -> UIViewController? {
            neighbor(of: viewController, step: -1)
        }

        func pageViewController(_ pageViewController: UIPageViewController,
                                viewControllerAfter viewController: UIViewController) -> UIViewController? {
            neighbor(of: viewController, step: 1)
        }

        func pageViewController(_ pageViewController: UIPageViewController,
                                willTransitionTo pendingViewControllers: [UIViewController]) {
            isTurning = true
        }

        func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool,
                                previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
            isTurning = false
            if completed, let current = pageViewController.viewControllers?.first as? Page {
                parent.onTurn(current.position)
            }
        }
    }
}

struct ContentsView: View {
    @EnvironmentObject private var archive: Archive
    @Environment(\.dismiss) private var dismiss
    @Binding var book: Volume
    let jump: (Int) -> Void
    @State private var naming = false
    @State private var name = ""

    private var activeChapter: Int? {
        book.pages.indices.last { $0 <= book.position && book.pages[$0].chapter != nil }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                RoundControl(icon: "xmark", label: "Cerrar índice") { dismiss() }
                Spacer()
                Text("Capítulos").font(.system(.title, design: .serif))
                Spacer()
                RoundControl(icon: "bookmark", label: "Marcar página como inicio de capítulo") {
                    name = book.pages[book.position].chapter ?? ""
                    naming = true
                }
            }
            Text(book.title + " · Página \(book.position + 1)")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            ScrollView {
                VStack(spacing: 6) {
                    ForEach(Array(book.pages.enumerated()), id: \.element.id) { index, page in
                        if let chapter = page.chapter {
                            Button {
                                jump(index)
                                dismiss()
                            } label: {
                                HStack {
                                    Text(book.chapterNumber(at: index)).font(.system(.subheadline, design: .serif))
                                        .frame(width: 36)
                                    Text(chapter).font(.system(.title3, design: .serif))
                                    Spacer()
                                    Text("\(index + 1)").monospacedDigit().foregroundStyle(.secondary)
                                }
                                .padding(14)
                                .contentShape(Rectangle())
                                .background(index == activeChapter ? copper.opacity(0.13) : .clear,
                                            in: RoundedRectangle(cornerRadius: 10))
                            }
                            .buttonStyle(.plain)
                            Divider()
                        }
                    }
                }
            }
            Button {
                name = book.pages[book.position].chapter ?? ""
                naming = true
            } label: {
                Label(book.pages[book.position].chapter == nil ? "Iniciar capítulo en esta página" : "Editar capítulo de esta página",
                      systemImage: "bookmark")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(GlassButton())
        }
        .padding(23)
        .foregroundStyle(paper)
        .background(ink.ignoresSafeArea())
        .alert("Inicio de capítulo", isPresented: $naming) {
            TextField("Nombre del capítulo", text: $name)
            Button("Cancelar", role: .cancel) {}
            if book.pages[book.position].chapter != nil {
                Button("Quitar marca", role: .destructive) { mark(nil) }
            }
            Button("Listo") {
                let title = name.trimmingCharacters(in: .whitespacesAndNewlines)
                if !title.isEmpty { mark(title) }
            }
        } message: {
            Text("Página \(book.position + 1)")
        }
    }

    private func mark(_ chapter: String?) {
        var updated = book
        updated.pages[book.position].chapter = chapter
        if archive.save(updated) { book = updated }
    }
}

struct PageText: UIViewRepresentable {
    let page: Folio
    let size: CGSize

    func makeUIView(context: Context) -> PrintedPage {
        let view = PrintedPage()
        view.isOpaque = false
        view.backgroundColor = .clear
        view.isUserInteractionEnabled = false
        view.isAccessibilityElement = true
        return view
    }

    func updateUIView(_ view: PrintedPage, context: Context) {
        view.text = PageDocument.contents(of: page)
        view.pageSize = size
        view.objects = page.objects ?? []
        view.accessibilityLabel = page.text
        view.setNeedsDisplay()
    }

    func sizeThatFits(_ proposal: ProposedViewSize, uiView: PrintedPage, context: Context) -> CGSize? {
        size
    }
}

final class PrintedPage: UIView {
    var text = NSAttributedString(string: "")
    var pageSize = CGSize.zero
    var objects: [PageObject] = []

    override func draw(_ rect: CGRect) {
        guard text.length > 0, let context = UIGraphicsGetCurrentContext() else { return }
        let inked = NSMutableAttributedString(attributedString: text)
        inked.addAttribute(.foregroundColor, value: UIColor.label.resolvedColor(with: traitCollection),
                           range: NSRange(location: 0, length: inked.length))
        let page = PageTextLayout(text: inked, size: pageSize, objects: objects)
        context.clip(to: CGRect(origin: .zero, size: pageSize))
        page.manager.drawBackground(forGlyphRange: page.visibleGlyphs, at: .zero)
        page.manager.drawGlyphs(forGlyphRange: page.visibleGlyphs, at: .zero)
    }
}
