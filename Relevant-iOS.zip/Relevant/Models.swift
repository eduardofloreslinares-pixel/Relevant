import SwiftUI
import UIKit
import ImageIO

struct Folio: Codable, Identifiable {
    var id = UUID()
    var text = ""
    var richText: Data?
    var chapter: String?
}

struct Volume: Codable, Identifiable {
    var id = UUID()
    var title: String
    var proportion: Double = 1.48
    var cover: Data?
    var pages: [Folio] = [Folio()]
    var position = 0

    static let sample = Volume(title: "Crónicas de Lima", proportion: 1.57, pages: [
        Folio(text: """
        Salí de casa antes de que levantara la garúa. En la panadería de la esquina ya habían sacado la primera tanda, y el olor del pan llegaba hasta el cruce.

        En la libreta anoté la hora, el nombre de la calle y una frase que escuché al pasar. Meses después, lo único que seguía recordando con claridad era el ruido de las tazas detrás del mostrador.

        12 de junio · Barranco
        """, chapter: "La ciudad temprano"),
        Folio(text: """
        El camino bajaba entre paredes húmedas. Una vecina regaba sus plantas y dejaba la puerta entreabierta para oír la radio desde la vereda.

        Guardé aquí la dirección de la librería. La próxima vez quiero entrar sin mirar la hora.
        """),
        Folio(text: """
        En noviembre volví con el mismo cuaderno. Habían pintado la fachada de la librería, pero el dueño seguía dejando una silla junto a la entrada.

        Esta vez compré un libro. En la primera página anoté dónde lo encontré.
        """, chapter: "La vuelta")
    ])
}

@MainActor
final class Archive: ObservableObject {
    @Published private(set) var books: [Volume] = []
    @Published var problem: String?
    private let file = URL.applicationSupportDirectory.appendingPathComponent("Relevant.json")
    private var readable = true

    init() {
        guard FileManager.default.fileExists(atPath: file.path) else {
            books = [.sample]
            return
        }
        do {
            books = try JSONDecoder().decode([Volume].self, from: Data(contentsOf: file))
        } catch {
            readable = false
            problem = "No se pudo abrir la biblioteca guardada."
        }
    }

    @discardableResult
    func save(_ book: Volume) -> Bool {
        guard readable else {
            problem = "No se puede guardar mientras la biblioteca siga sin poder abrirse."
            return false
        }
        var updated = books
        if let index = updated.firstIndex(where: { $0.id == book.id }) {
            updated[index] = book
        } else {
            updated.insert(book, at: 0)
        }
        do {
            try FileManager.default.createDirectory(at: file.deletingLastPathComponent(),
                                                    withIntermediateDirectories: true)
            try JSONEncoder().encode(updated).write(to: file, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            books = updated
            return true
        } catch {
            problem = "No se pudieron guardar los cambios. Puedes volver a intentarlo."
            return false
        }
    }
}

func photoData(_ original: Data, maximum: Int) -> Data? {
    guard let source = CGImageSourceCreateWithData(original as CFData, nil),
          let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maximum
          ] as CFDictionary) else { return nil }
    return UIImage(cgImage: image).jpegData(compressionQuality: 0.83)
}
