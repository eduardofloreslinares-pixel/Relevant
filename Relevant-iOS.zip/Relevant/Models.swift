import SwiftUI
import UIKit
import ImageIO

struct Folio: Codable, Identifiable, Equatable {
    var id = UUID()
    var text = ""
    var richText: Data?
    var chapter: String?
    var objects: [PageObject]?
}

struct Volume: Codable, Identifiable {
    var id = UUID()
    var title: String
    var proportion: Double = 1.48
    var cover: Data?
    var pages: [Folio] = [Folio()]
    var position = 0

    static let sample = Volume(title: "Crónicas de Lima", proportion: 1.57, pages: [
        Folio(text: """
        Salí de casa antes de que levantara la garúa. En la panadería de la esquina ya habían sacado la primera tanda, y el olor del pan llegaba hasta el cruce.

        En la libreta anoté la hora, el nombre de la calle y una frase que escuché al pasar. Meses después, lo único que seguía recordando con claridad era el ruido de las tazas detrás del mostrador.

        12 de junio · Barranco
        """, chapter: "La ciudad temprano"),
        Folio(text: """
        El camino bajaba entre paredes húmedas. Una vecina regaba sus plantas y dejaba la puerta entreabierta para oír la radio desde la vereda.

        Guardé aquí la dirección de la librería. La próxima vez quiero entrar sin mirar la hora.
        """),
        Folio(text: """
        En noviembre volví con el mismo cuaderno. Habían pintado la fachada de la librería, pero el dueño seguía dejando una silla junto a la entrada.

        Esta vez compré un libro. En la primera página anoté dónde lo encontré.
        """, chapter: "La vuelta")
    ])
}

@MainActor
final class Archive: ObservableObject {
    @Published private(set) var books: [Volume] = []
    @Published var problem: String?
    private let file = URL.applicationSupportDirectory.appendingPathComponent("Relevant.json")
    private var readable = true

    init() {
        guard FileManager.default.fileExists(atPath: file.path) else {
            books = [.sample]
            return
        }
        do {
            books = try JSONDecoder().decode([Volume].self, from: Data(contentsOf: file))
        } catch {
            readable = false
            problem = "No se pudo abrir la biblioteca guardada."
        }
    }

    @discardableResult
    func save(_ book: Volume) -> Bool {
        var updated = books
        if let index = updated.firstIndex(where: { $0.id == book.id }) {
            updated[index] = book
        } else {
            updated.insert(book, at: 0)
        }
        return persist(updated)
    }

    func remove(_ id: UUID) {
        _ = persist(books.filter { $0.id != id })
    }

    private func persist(_ updated: [Volume]) -> Bool {
        guard readable else {
            problem = "No se puede guardar mientras la biblioteca siga sin poder abrirse."
            return false
        }
        do {
            try FileManager.default.createDirectory(at: file.deletingLastPathComponent(),
                                                    withIntermediateDirectories: true)
            try JSONEncoder().encode(updated).write(to: file, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            books = updated
            return true
        } catch {
            problem = "No se pudieron guardar los cambios. Puedes volver a intentarlo."
            return false
        }
    }
}

func photoData(_ original: Data, maximum: Int) -> Data? {
    guard let source = CGImageSourceCreateWithData(original as CFData, nil),
          let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maximum
          ] as CFDictionary) else { return nil }
    return UIImage(cgImage: image).jpegData(compressionQuality: 0.83)
}

struct PageObject: Codable, Identifiable, Equatable {
    enum Kind: String, Codable { case photo, drawing, table }
    var id = UUID()
    var kind: Kind
    var image: Data?
    var cells: [[String]]?
    var x = 0.68
    var y = 0.36
    var width = 0.43
    var aspect = 1.0
    var rotation: Double?
    var usesFreePosition: Bool?

    var isFreeformArtwork: Bool { kind == .photo || kind == .drawing }

    func fitsInside(_ size: CGSize) -> Bool {
        guard isFreeformArtwork else { return true }
        let frame = rect(in: size)
        let theta = CGFloat(rotation ?? 0) * .pi / 180
        let halfWidth = (abs(cos(theta)) * frame.width + abs(sin(theta)) * frame.height) / 2
        let halfHeight = (abs(sin(theta)) * frame.width + abs(cos(theta)) * frame.height) / 2
        return frame.midX - halfWidth >= -0.5 && frame.midX + halfWidth <= size.width + 0.5
            && frame.midY - halfHeight >= -0.5 && frame.midY + halfHeight <= size.height + 0.5
    }

    func rect(in size: CGSize) -> CGRect {
        let ratio = max(aspect, 0.08)
        if usesFreePosition == true {
            let w = size.width * width
            let h = w / ratio
            return CGRect(x: x * size.width - w / 2, y: y * size.height - h / 2, width: w, height: h)
        }
        let w = min(size.width * width, size.width)
        let h = min(w / ratio, size.height * 0.65)
        return CGRect(x: max(0, min(size.width - w, x * size.width - w / 2)),
                      y: max(0, min(size.height - h, y * size.height - h / 2)),
                      width: w, height: h)
    }
}

func roman(_ number: Int) -> String {
    var remainder = number
    var result = ""
    for (value, symbol) in [(1000,"M"),(900,"CM"),(500,"D"),(400,"CD"),(100,"C"),(90,"XC"),
                            (50,"L"),(40,"XL"),(10,"X"),(9,"IX"),(5,"V"),(4,"IV"),(1,"I")] {
        while remainder >= value { result += symbol; remainder -= value }
    }
    return result
}

extension Volume {
    func chapterNumber(at position: Int) -> String {
        roman(pages.prefix(position + 1).filter { $0.chapter != nil }.count)
    }
}
