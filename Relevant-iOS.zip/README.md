# Relevant

An iOS library for personal records. The first launch includes **Crónicas de Lima**, an example book with three pages and two chapters. Books and edits are stored locally.

## To try it

1. Open the sample book. Swipe sideways to turn a page, or tap the page to reveal the reader controls. Long text flows onto additional pages automatically.
2. Tap the pencil, write a line, and try **Nueva página** on the final page. Tap **Listo** to return to reading. The editor saves when advancing, when closing, or when the app enters the background.
3. Tap the reader’s lower **…**. Mark the current page as a chapter start, then jump to that entry from the chapter list.
4. Back in the library, use **+** to create a book. The height slider changes the cover preview while you drag it. Search checks book titles, chapter names, and page text.

To move, resize, or remove an item, tap **Colocar objetos** in the editor. In **Composición**, drag items into place and use the size slider. Select a table and tap its grid button to edit its cells.

## Build on GitHub

Extract the ZIP and put its contents at the repository root, including `.github/workflows/build-ios.yml`. If you upload the ZIP itself, also place the included workflow in that same path at the repository root so GitHub can start it and unpack the ZIP.

Open **Actions → Build Relevant IPA → Run workflow**. Download the **Relevant-iOS** artifact and extract `Relevant.ipa`. The updated workflow selects Xcode 26 for native Liquid Glass on iOS 26+. The IPA is unsigned and must be signed by your sideloading tool. Keep the same bundle identifier when installing updates to preserve the app’s data.

On a Mac, you can also open `Relevant.xcodeproj` in Xcode 26 or later (for Liquid Glass) and run the Relevant scheme on an iOS 18+ simulator.
