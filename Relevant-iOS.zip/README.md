# Relevant

An iOS library for personal records. The first launch includes **Crónicas de Lima**, an example book with three pages and two chapters. Books and edits are stored locally.

## To try it

1. Open the sample book. Drag left or right to curl the full page like a sheet of paper. Release early or drag back to cancel. Drag vertically to interact with the zoom transition back to the book cover. Tap the page to toggle the controls. The editor opens at the current page and scrolls continuously. Gray numbered separators mark the sheets. Text that exceeds a sheet continues at the beginning of the next page and pushes its existing text forward as needed. More pages are added at the end of the book when necessary.
2. Tap the pencil, write a line, and try **Nueva página** on the final page. Tap **Listo** to return to reading. The editor saves when advancing, when closing, or when the app enters the background.
3. Tap the reader’s lower **…**. Mark the current page as a chapter start, then jump to that entry from the chapter list.
4. Back in the library, use **+** to create a book. The height slider changes the cover preview while you drag it. Search checks book titles, chapter names, and page text.

Photos and new drawings target the page with the most area visible when you insert them. To move, resize, or remove an item, tap **Colocar objetos** in the editor. In **Composición**, drag items into place and use the size slider. Photos and drawings can also be resized with a pinch and rotated with two fingers. A red × marks an object that needs to be moved or resized before you can apply the layout. Cancel closes the preview without inserting a new photo or drawing. Select a table and tap its grid button to edit its cells.

## Build on GitHub

Extract the ZIP and put its contents at the repository root, including `.github/workflows/build-ios.yml`. If you upload the ZIP itself, also place the included workflow in that same path at the repository root so GitHub can start it and unpack the ZIP.

Open **Actions → Build Relevant IPA → Run workflow**. Download the **Relevant-iOS** artifact and extract `Relevant.ipa`. The updated workflow selects Xcode 26 for native Liquid Glass on iOS 26+. The IPA is unsigned and must be signed by your sideloading tool. Keep the same bundle identifier when installing updates to preserve the app’s data.

On a Mac, you can also open `Relevant.xcodeproj` in Xcode 26 or later (for Liquid Glass) and run the Relevant scheme on an iOS 18+ simulator.
